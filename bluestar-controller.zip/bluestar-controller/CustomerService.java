package com.juv.bluestar.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;























import com.bluestar.serveit.common.constants.StatusConstants;
import com.bluestar.serveit.common.helper.TicketScenario;
import com.google.gson.Gson;
import com.juv.bluestar.adaptar.TicketAdaptar;
import com.juv.bluestar.beans.ErrorMessage;
import com.juv.bluestar.beans.Notification;
import com.juv.bluestar.beans.OTPMobileNoRequestBean;
import com.juv.bluestar.beans.ProductBean;
import com.juv.bluestar.beans.StatusTrackingBean;
import com.juv.bluestar.beans.SubmitFeedbackBean;
import com.juv.bluestar.beans.Ticket;
import com.juv.bluestar.beans.TicketBean;
import com.juv.bluestar.beans.UserBean;
import com.juv.bluestar.common.db.model.AddressmasterDTO;
import com.juv.bluestar.common.db.model.CommunicationDetailsDTO;
import com.juv.bluestar.common.db.model.CustfeedbackDTO;
import com.juv.bluestar.common.db.model.CustomerdetailsDTO;
import com.juv.bluestar.common.db.model.CustomerotpDTO;
import com.juv.bluestar.common.db.model.FranchiseeDetailsDTO;
import com.juv.bluestar.common.db.model.ProductmasterDTO;
import com.juv.bluestar.common.db.model.RetailerMasterDTO;
import com.juv.bluestar.common.db.model.StatusmasterDTO;
import com.juv.bluestar.common.db.model.TicketAllDTO;
import com.juv.bluestar.common.db.model.TicketCreationDTO;
import com.juv.bluestar.common.db.model.TicketDTO;
import com.juv.bluestar.common.db.model.TicketdetailsAllDTO;
import com.juv.bluestar.common.db.model.TicketdetailsDTO;
import com.juv.bluestar.common.db.service.CustomerdetailsDBService;
import com.juv.bluestar.common.db.service.CustomerotpDBService;
import com.juv.bluestar.common.db.service.ProductmasterDBService;
import com.juv.bluestar.common.db.service.TicketdetailsDBService;
import com.juv.bluestar.common.db.service.impl.AddressmasterDBServiceImpl;
import com.juv.bluestar.common.db.service.impl.CustfeedbackDBServiceImpl;
import com.juv.bluestar.common.db.service.impl.CustomerdetailsDBServiceImpl;
import com.juv.bluestar.common.db.service.impl.CustomerotpDBServiceImpl;
import com.juv.bluestar.common.db.service.impl.ProductmasterDBServiceImpl;
import com.juv.bluestar.common.db.service.impl.StatusmasterDBServiceImpl;
import com.juv.bluestar.common.db.service.impl.TicketAllDBServiceImpl;
import com.juv.bluestar.common.db.service.impl.TicketDBServiceImpl;
import com.juv.bluestar.common.db.service.impl.TicketdetailsAllDBServiceImpl;
import com.juv.bluestar.common.db.service.impl.TicketdetailsDBServiceImpl;
import com.juv.bluestar.common.exceptions.DBException;
import com.juv.bluestar.exception.BluestarBusinessException;
import com.juv.bluestar.exception.CustomerNotFoundException;
import com.juv.bluestar.exception.ProductNotFoundException;
import com.juv.bluestar.helper.ApplicationLogger;
import com.juv.bluestar.helper.CallLoggingHelper;
import com.juv.bluestar.helper.GenericConstants;

@Service
public class CustomerService implements ICustomerService {
	private static final int CALL_CLOSE_STATUS_ID = 1015;

	private CustomerdetailsDBService customerdetailsDBService;
	private CustomerotpDBService customerotpDBService;
	private ProductmasterDBService productmasterDBService;
	private TicketdetailsDBService ticketdetailsDBService;
	private TicketAdaptar ticketAdaptar;

	@Autowired
	public void setTicketAdaptar(TicketAdaptar ticketAdaptar) {
		this.ticketAdaptar = ticketAdaptar;
	}

	@Autowired
	public void setProductmasterDBService(
			ProductmasterDBService productmasterDBService) {
		this.productmasterDBService = productmasterDBService;
	}

	@Autowired
	public void setCustomerotpDBService(
			CustomerotpDBService customerotpDBService) {
		this.customerotpDBService = customerotpDBService;
	}

	@Autowired
	public void setTicketdetailsDBService(
			TicketdetailsDBService ticketdetailsDBService) {
		this.ticketdetailsDBService = ticketdetailsDBService;
	}

	@Autowired
	public void setCustomerdetailsDBService(
			CustomerdetailsDBService customerdetailsDBService) {
		this.customerdetailsDBService = customerdetailsDBService;
	}

	public boolean saveUser() {

		try {
			List<CustomerotpDTO> dtos = this.customerotpDBService
					.getCustomerotp(null, null, false);
			System.out.println(dtos);
		} catch (DBException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		CustomerotpDTO dto2 = new CustomerotpDTO();
		dto2.setId(11);
		dto2.setDatetime(new Timestamp(new Date().getTime()));
		dto2.setMobilenumber(9953503835l);
		dto2.setOtp(112121);

		try {
			this.customerotpDBService.insertSingleCustomerotp(dto2);
		} catch (DBException e) {
			e.printStackTrace();
		}
		return false;
	}

	public List<ProductBean> getProducts() throws Exception {
		List<ProductBean> listNew = new ArrayList<ProductBean>();
		List<ProductmasterDTO> list = this.productmasterDBService
				.getProductmaster(null, null, false);
		if (list == null || list.size() < 1) {
			throw new Exception();
		}
		for (ProductmasterDTO dto : list) {
			ProductBean bean = new ProductBean();
			bean.setProductId(dto.getProductId() + "");
			bean.setProductname(dto.getProductname());
			bean.setProductImage("http://203.76.134.156/EnhancedTheme/themes/html/Enhanced/css/images/bluestarAC.jpg");
			listNew.add(bean);
		}
		return listNew;
	}

	public TicketBean getTicketById(int ticketId)
			throws ProductNotFoundException, BluestarBusinessException {

		// fetch ticket
		TicketdetailsDTO ticketS = new TicketdetailsDTO();
		ticketS.setTicketId(ticketId);
		List<TicketdetailsDTO> ticketDTOs;
		try {
			ticketDTOs = this.ticketdetailsDBService.getTicketdetails(ticketS,
					null, false);
		} catch (DBException e1) {
			throw new BluestarBusinessException("ticket not found");
		}
		TicketdetailsDTO ticketDTO2 = ticketDTOs.get(0);
		TicketBean ticketBean = this.ticketAdaptar.TicketDTOtoBean(ticketDTO2);

		// update product
		ProductmasterDTO productmasterDTO = new ProductmasterDTO();
		productmasterDTO.setProductId(ticketDTO2.getProductId());
		List<ProductmasterDTO> productmasters;
		ProductmasterDTO product = new ProductmasterDTO();
		try {
			productmasters = this.productmasterDBService.getProductmaster(
					productmasterDTO, null, false);
			if (productmasters == null || productmasters.size() == 0) {
				throw new ProductNotFoundException("Product not found");
			}
			product = productmasters.get(0);
		} catch (DBException e) {
			throw new ProductNotFoundException("Product not found");
		}
		ticketBean.setProductName(product.getProductname());

		return ticketBean;
	}

	public boolean registerUser(UserBean userBean,String mobile) throws Exception {
		String json = null;
		String strlist = null;
		if(userBean.getAddresses() != null || userBean.getAddresses().size() > 0){
			ArrayList<Object> listadd = userBean.getAddresses();
		    strlist = String.valueOf(listadd);
			Gson gson = new Gson();
			 json = gson.toJson(listadd);
		}
		
		//System.out.println("Json array :"+(JSONArray)JSONSerializer.toJSON(listadd));
		
		if(strlist.contains("=")){
			strlist = strlist.replaceAll("=", ":");
		}
		String str = null;
		if(json != null || json != ""){
			str = "{\"addresses\":"+json+"}";
		}
		boolean status = false;
		CustomerdetailsDBServiceImpl impl = new CustomerdetailsDBServiceImpl();
		CustomerdetailsDTO customerdetails = new CustomerdetailsDTO();
		AddressmasterDBServiceImpl addImpl = new AddressmasterDBServiceImpl();
		String name = userBean.getFirstName();
		name = name +" ";
		name += (userBean.getLastName() != null) ? userBean.getLastName() : "";
		customerdetails.setCustomername(name);
		customerdetails.setEmail(userBean.getEmail());
		if(userBean.getPrefferedTimingFrom() == null || userBean.getPrefferedTimingFrom().trim() == ""){
			customerdetails.setPreferredtimingsfrom(null);
		}else{
			customerdetails.setPreferredtimingsfrom(userBean
					.getPrefferedTimingFrom());
		}
		if(userBean.getPrefferedTimingTo() == null || userBean.getPrefferedTimingTo().trim() == ""){
			customerdetails.setPreferredtimingsto(null);
		}else{
			customerdetails.setPreferredtimingsto(userBean.getPrefferedTimingTo());
		}
		if(userBean.getPin() == null || userBean.getPin().trim() == ""){
			customerdetails.setPincode("");
			
		}else{
			customerdetails.setPincode(userBean.getPin());
		}
		
		customerdetails.setSecurityanswer(userBean.getSecurityQuestionAnswer());
		customerdetails.setSecurityquestion(userBean.getSecurityQuestionId());
		customerdetails.setMobile(mobile);
		customerdetails.setAlternatemobile(userBean.getAlternatemobilenumber());
		CustomerdetailsDTO customerdetailsDTO = new CustomerdetailsDTO();
		customerdetailsDTO.setMobile(mobile);
		CustomerdetailsDTO customerdetailsconditional = new CustomerdetailsDTO();
		customerdetailsconditional.setMobile(mobile);
		List<CustomerdetailsDTO> list = impl.getCustomerdetails(customerdetailsDTO, null, false);
		//JSONObject addressjson = userBean.getAddresses();
		//String addresslist1 = addressjson.toString();
		//System.out.println("Address list get :"+addresslist1);
		if(list.size() > 0){
			//System.out.println("Inside update");
			//String address = "{"+userBean.getAddresslist()+"}";
			//System.out.println("Address list :"+address);
			
			CustomerdetailsDTO custDto2 = new CustomerdetailsDTO();
			custDto2 = list.get(0);
			int customerdetailid = (int) custDto2.getCustomerdetailsId();
			if(str == null || str == ""){
				System.out.println("if address list is null");
				AddressmasterDTO addressmasterDTO = new AddressmasterDTO();
				addressmasterDTO.setCustomerid(customerdetailid);
				List<AddressmasterDTO> addresslist = addImpl.getAddressmaster(addressmasterDTO, null, false);
				for (AddressmasterDTO addressmasterDTO2 : addresslist) {
					AddressmasterDTO addressmas = new AddressmasterDTO();
					addressmas.setCustomerid(addressmasterDTO2.getCustomerid());
					int i = addImpl.deleteAddressmaster(addressmas, null, false);
				}
			}else{
				//String addresses = "{"+userBean.getAddresses()+"}";
				//System.out.println("Address list after add of curly :"+addresses);
				JSONObject obj = new JSONObject(str);
				List<ArrayList<String>> lists = new ArrayList<ArrayList<String>>();
				ArrayList<String> listtemp = new ArrayList<String>();
				JSONArray array = obj.getJSONArray("addresses");
				for(int i = 0 ; i < array.length() ; i++){
					ArrayList<String> list1 = new ArrayList<String>();
					if(array.getJSONObject(i).getString("address") == null || array.getJSONObject(i).getString("address") == ""){
						list1.add(" ");
					}else{
						list1.add(array.getJSONObject(i).getString("address"));
					}
					if(array.getJSONObject(i).getString("locality") == null || array.getJSONObject(i).getString("locality") == ""){
						list1.add(" ");
					}else{
						list1.add(array.getJSONObject(i).getString("locality"));
					}
					if(array.getJSONObject(i).getString("pinCode") == null || array.getJSONObject(i).getString("pinCode") == " "){
						list1.add(" ");
					}else{
						list1.add(array.getJSONObject(i).getString("pinCode"));	
					}
					if(array.getJSONObject(i).getString("city") == null || array.getJSONObject(i).getString("city") == ""){
						list1.add(" ");
					}else{
						list1.add(array.getJSONObject(i).getString("city"));	
					}
					if(array.getJSONObject(i).getString("state") == null || array.getJSONObject(i).getString("state") ==""){
						list1.add(" ");
					}else{
						list1.add(array.getJSONObject(i).getString("state"));	
					}
					if(array.getJSONObject(i).getString("isPrimaryAddress") == null || array.getJSONObject(i).getString("isPrimaryAddress") ==""){
						list1.add(" ");
					}else{
						list1.add(array.getJSONObject(i).getString("isPrimaryAddress"));	
					}
					
					lists.add(list1);
				}
				int addresscount = lists.size();
				AddressmasterDTO addressmasterDTO = new AddressmasterDTO();
				addressmasterDTO.setCustomerid(customerdetailid);
				List<AddressmasterDTO> addresslist = addImpl.getAddressmaster(addressmasterDTO, null, false);
				System.out.println("Address size :"+addresslist.size());
				if(addresslist.size() == 0){
					System.out.println("If addresslist.size == 0");
					AddressmasterDTO addDto = new AddressmasterDTO();
					if(lists.size() > 0){
						int listpoint = 0;
						for (List<String> list2 : lists) {
							//System.out.println("list2 isprimary :"+list2.get(5));
							if(list2.get(5).equals("false")){
							//System.out.println("list2 isprimary is false");
							addDto.setAddress(list2.get(0));
							addDto.setLocality(list2.get(1));
							addDto.setPincode(list2.get(2));
							addDto.setCity(list2.get(3));
							addDto.setState(list2.get(4));
							addDto.setCustomerid(customerdetailid);
							long k = addImpl.insertSingleAddressmaster(addDto);
							}else if(list2.get(5).equals("true")){
								System.out.println("list2 isprimary is true");
								CustomerdetailsDTO custdto = new CustomerdetailsDTO();
								custdto.setAddress1(list2.get(0));
								custdto.setLocality(list2.get(1));
								custdto.setPinnumber(list2.get(2));
								custdto.setCity(list2.get(3));
								custdto.setState(list2.get(4));
								CustomerdetailsDTO conditionaldto = new CustomerdetailsDTO();
								conditionaldto.setMobile(mobile);
								int res = impl.updateCustomerdetails(custdto, conditionaldto, null, false);
								//System.out.println("After update of customerdetails data");
							}
							listpoint++;
						}
					}
				}else if(addresslist.size() > (lists.size()-1)){
					   System.out.println("If list size less than addresslist size");
						CustomerdetailsDTO custDto = new CustomerdetailsDTO();
						AddressmasterDTO addDto = new AddressmasterDTO();
						int l = 0;
						int listpoint =0;
						for (List<String> list2 : lists) {
							if(list2.get(5).equals("false")){
								System.out.println("If list isprimary false");
							addDto.setAddress(list2.get(0));
							addDto.setLocality(list2.get(1));
							addDto.setPincode(list2.get(2));
							addDto.setCity(list2.get(3));
							addDto.setState(list2.get(4));
							//addDto.setCustomerid(customerdetailid);
							AddressmasterDTO addressmasterDTO2 = new AddressmasterDTO();
							addressmasterDTO2 = addresslist.get(l);
							AddressmasterDTO addressmasterDTOConditionalData = new AddressmasterDTO();
							addressmasterDTOConditionalData.setAddressid(addressmasterDTO2.getAddressid());
							long k = addImpl.updateAddressmaster(addDto, addressmasterDTOConditionalData, null, false);
							l++;
							}else if(list2.get(5).equals("true")){
								System.out.println("If list isprimary true");
								CustomerdetailsDTO custdto = new CustomerdetailsDTO();
								custdto.setAddress1(list2.get(0));
								custdto.setLocality(list2.get(1));
								custdto.setPinnumber(list2.get(2));
								custdto.setCity(list2.get(3));
								custdto.setState(list2.get(4));
								CustomerdetailsDTO conditionaldto = new CustomerdetailsDTO();
								conditionaldto.setMobile(mobile);
								int res = impl.updateCustomerdetails(custdto, conditionaldto, null, false);
							}
							listpoint++;
						}
						//System.out.println("Outside for loop:::::::::::::");
						int addlistsize = addresslist.size() - (lists.size()-1);
						//System.out.println("L value :"+l);
						//System.out.println("Limit :"+(addresslist.size()-(l)));
						int addresssize = addresslist.size();
						for(int k = 0;k<=(addresssize-(l));k++){
							/*System.out.println("L value inside for loop"+l);
							System.out.println("Address list :"+addresssize);
							System.out.println("Inside delete for loop");*/
							//System.out.println("");
							AddressmasterDTO addressmasterDTO2 = new AddressmasterDTO();
							addressmasterDTO2 = addresslist.get(l);
							AddressmasterDTO addressmasterDTO3 = new AddressmasterDTO();
							addressmasterDTO3.setAddressid(addressmasterDTO2.getAddressid());
							int i = addImpl.deleteAddressmaster(addressmasterDTO3, null, false);
							//System.out.println("Deleted row:"+i);
							l++;
						}
					
				}else if(addresslist.size() < (lists.size()-1)){
					System.out.println("If list size greater than addresslist size");
					CustomerdetailsDTO custDto = new CustomerdetailsDTO();
					AddressmasterDTO addDto = new AddressmasterDTO();
					CustomerdetailsDTO customerdetailsDTO2 = new CustomerdetailsDTO();
					customerdetailsDTO2.setMobile(mobile);
					List<CustomerdetailsDTO> cuslist = impl.getCustomerdetails(customerdetailsDTO2, null, false);
					CustomerdetailsDTO customerDto = cuslist.get(0);
					addDto.setCustomerid((int) customerDto.getCustomerdetailsId());
					//CustomerdetailsDTO custDto = new CustomerdetailsDTO();
					//AddressmasterDTO addDto = new AddressmasterDTO();
					List<AddressmasterDTO> addressmasterDTOs = addImpl.getAddressmaster(addDto, null, false);
					//System.out.println("addressmasterlist :"+addresslist.size());
					int l = 0;
					int listpoint = 0;
					for (int m = 0;m < (addresslist.size()+1);m++) {
						//System.out.println("m value :"+m);
						AddressmasterDTO addressmasterDTO2 = new AddressmasterDTO();
						List<String> list2 = lists.get(m);
						//System.out.println("List :"+m+" ::::"+list2);
						if(list2.get(5).equals("false")){
						addressmasterDTO2 = addressmasterDTOs.get(l);
						//System.out.println("If list isprimary is false");
						addDto.setAddress(list2.get(0));
						addDto.setLocality(list2.get(1));
						addDto.setPincode(list2.get(2));
						addDto.setCity(list2.get(3));
						addDto.setState(list2.get(4));
						//addDto.setCustomerid(customerdetailid);
						//AddressmasterDTO addressmasterDTO3 = new AddressmasterDTO();
						//addressmasterDTO3 = addresslist.get(l);
						AddressmasterDTO addressmasterDTOConditionalData = new AddressmasterDTO();
						addressmasterDTOConditionalData.setAddressid(addressmasterDTO2.getAddressid());
						long k = addImpl.updateAddressmaster(addDto, addressmasterDTOConditionalData, null, false);
						//System.out.println("updateed list size :"+k);
						l++;
						}else if(list2.get(5).equals("true")){
							System.out.println("If list isprimary is true");
							CustomerdetailsDTO custdto = new CustomerdetailsDTO();
							custdto.setAddress1(list2.get(0));
							custdto.setLocality(list2.get(1));
							custdto.setPinnumber(list2.get(2));
							custdto.setCity(list2.get(3));
							custdto.setState(list2.get(4));
							CustomerdetailsDTO conditionaldto = new CustomerdetailsDTO();
							conditionaldto.setMobile(mobile);
							int res = impl.updateCustomerdetails(custdto, conditionaldto, null, false);
							//System.out.println("Updatedcustomer details :"+res);
						}
						listpoint++;
						
					}
					int addlistsize = (lists.size()-1) - addresslist.size();
					//System.out.println("Addresslistr :"+addlistsize);
					for(int k = addlistsize;k<(lists.size()-1);k++){
						//System.out.println("listpoint :"+listpoint);
						List<String> list2 = lists.get(listpoint);
						addDto.setAddress(list2.get(0));
						addDto.setLocality(list2.get(1));
						addDto.setPincode(list2.get(2));
						addDto.setCity(list2.get(3));
						addDto.setState(list2.get(4));
						addDto.setCustomerid(customerdetailid);
						long m = addImpl.insertSingleAddressmaster(addDto);
						//System.out.println("Inserted data list :"+m);
						l++;
					}	
				}else if(addresslist.size() == (lists.size()-1)){
					//System.out.println("Inside else");
					CustomerdetailsDTO custDto = new CustomerdetailsDTO();
					AddressmasterDTO addDto = new AddressmasterDTO();
					CustomerdetailsDTO customerdetailsDTO2 = new CustomerdetailsDTO();
					customerdetailsDTO2.setMobile(mobile);
					List<CustomerdetailsDTO> cuslist = impl.getCustomerdetails(customerdetailsDTO2, null, false);
					CustomerdetailsDTO customerDto = cuslist.get(0);
					addDto.setCustomerid((int) customerDto.getCustomerdetailsId());
					
					List<AddressmasterDTO> addressmasterDTOs = addImpl.getAddressmaster(addDto, null, false);
					System.out.println("Inside else ****************************");
					int l =0;
					int listpoint = 0;
					for (List<String> list2 : lists) {
						if(list2.get(5).equals("false")){
						int addsize = addressmasterDTOs.size();
						AddressmasterDTO addressmasterDTO2 = new AddressmasterDTO();
						addressmasterDTO2 = addressmasterDTOs.get(l);
						addDto.setAddress(list2.get(0));
						addDto.setLocality(list2.get(1));
						addDto.setPincode(list2.get(2));
						addDto.setCity(list2.get(3));
						addDto.setState(list2.get(4));
						//System.out.println("Address:"+addressmasterDTO2.getAddress());
						//System.out.println("AddressId"+addressmasterDTO2.getAddressid());
						//addDto.setCustomerid(customerdetailid);
						
						//addressmasterDTO2 = 
						
						AddressmasterDTO addressmasterDTOConditionalData = new AddressmasterDTO();
						addressmasterDTOConditionalData.setAddressid(addressmasterDTO2.getAddressid());
						long k = addImpl.updateAddressmaster(addDto, addressmasterDTOConditionalData, null, false);
						//System.out.println("Updated Row :"+k);
						l++;
						}else if(list2.get(5).equals("true")){
							CustomerdetailsDTO custdto = new CustomerdetailsDTO();
							custdto.setAddress1(list2.get(0));
							custdto.setLocality(list2.get(1));
							custdto.setPinnumber(list2.get(2));
							custdto.setCity(list2.get(3));
							custdto.setState(list2.get(4));
							CustomerdetailsDTO conditionaldto = new CustomerdetailsDTO();
							conditionaldto.setMobile(mobile);
							int res = impl.updateCustomerdetails(custdto, conditionaldto, null, false);
						}
						listpoint++;
					}
				}
				System.out.println("List :"+lists);
			}
			int j = impl.updateCustomerdetails(customerdetails, customerdetailsconditional, null, false);
			status = true;
			
		}else{
			System.out.println("Inside insert");
			//long result = impl.insertSingleCustomerdetails(customerdetails);
			//System.out.println("");
			//String addresses = "{"+userBean.getAddresses()+"}";
			JSONObject obj = new JSONObject(str);
			List<ArrayList<String>> lists = new ArrayList<ArrayList<String>>();
			ArrayList<String> listtemp = new ArrayList<String>();
			JSONArray array = obj.getJSONArray("addresses");
			//System.out.println("Length :"+array.length());
			for(int i = 0 ; i < array.length() ; i++){
				ArrayList<String> list1 = new ArrayList<String>();
				if(array.getJSONObject(i).getString("address") == null || array.getJSONObject(i).getString("address") == ""){
					list1.add(" ");
				}else{
					list1.add(array.getJSONObject(i).getString("address"));	
				}
				if(array.getJSONObject(i).getString("locality") == null || array.getJSONObject(i).getString("locality") == ""){
					list1.add(" ");
				}else{
					list1.add(array.getJSONObject(i).getString("locality"));	
				}
				if(array.getJSONObject(i).getString("pinCode") == null || array.getJSONObject(i).getString("pinCode") == ""){
					list1.add(" ");
				}else{
					list1.add(array.getJSONObject(i).getString("pinCode"));	
				}
				if(array.getJSONObject(i).getString("city") == null || array.getJSONObject(i).getString("city") == ""){
					list1.add(" ");
				}else{
					list1.add(array.getJSONObject(i).getString("city"));	
				}
				if(array.getJSONObject(i).getString("state") == null || array.getJSONObject(i).getString("state") ==""){
					list1.add(" ");
				}else{
					list1.add(array.getJSONObject(i).getString("state"));	
				}
				if(array.getJSONObject(i).getString("isPrimaryAddress") == null || array.getJSONObject(i).getString("isPrimaryAddress") ==""){
					list1.add(" ");
				}else{
					list1.add(array.getJSONObject(i).getString("isPrimaryAddress"));	
				}
				
				lists.add(list1);
			}
			
			
			//System.out.println("List :"+lists);
			long result = impl.insertSingleCustomerdetails(customerdetails);
			//
			CustomerdetailsDTO custDto = new CustomerdetailsDTO();
			custDto.setMobile(mobile);
			List<CustomerdetailsDTO> cusdetailsDtos = impl.getCustomerdetails(custDto, null, false);
			CustomerdetailsDTO custDto2 = new CustomerdetailsDTO();
			custDto2 = cusdetailsDtos.get(0);
			
			
			int customerid = (int) custDto2.getCustomerdetailsId();
			AddressmasterDTO addDto = new AddressmasterDTO();
			if(lists.size() > 0){
				for (List<String> list2 : lists) {
					if(list2.get(5).equals("false")){
						System.out.println("If isPrimaryaddress is false");
					addDto.setAddress(list2.get(0));
					addDto.setLocality(list2.get(1));
					addDto.setPincode(list2.get(2));
					addDto.setCity(list2.get(3));
					addDto.setState(list2.get(4));
					addDto.setCustomerid(customerid);
					long j = addImpl.insertSingleAddressmaster(addDto);
					
					}else if(list2.get(5).equals("true")){
						System.out.println("If isPrimaryaddress is true");
						CustomerdetailsDTO customerdetailsDTO2 = new CustomerdetailsDTO();
						customerdetailsDTO2.setAddress1(list2.get(0));
						customerdetailsDTO2.setLocality(list2.get(1));
						customerdetailsDTO2.setPinnumber(list2.get(2));
						customerdetailsDTO2.setCity(list2.get(3));
						customerdetailsDTO2.setState(list2.get(4));
						CustomerdetailsDTO customerdetailsconditional1 = new CustomerdetailsDTO();
						customerdetailsconditional1.setCustomerdetailsId(customerid);
						long resp = impl.updateCustomerdetails(customerdetailsDTO2, customerdetailsconditional1, null, false);
						//System.out.println("Response after update of primary address:"+resp);
					}
				}
				
				
			}
			
			status = true;
		}
		/*
		 * if(add != null && add.length > 0) { if(add.length == 1) {
		 * customerdetails.se } else if (add.length == 1) {
		 * 
		 * } for(String address : add) { customerdetails.se } }
		 */
		//this.customerdetailsDBService.insertSingleCustomerdetails(customerdetails);

		return status;
	}

	public boolean verifySecurityQuestion(String phonenumber,
			String questionId, String questionAUnswer)
			throws CustomerNotFoundException, BluestarBusinessException {
		// TODO Auto-generated method stub
		Boolean res = false;
		CustomerdetailsDTO customerdetailsDTO = new CustomerdetailsDTO();
		List<CustomerdetailsDTO> customerlist = null;
		customerdetailsDTO.setMobile(phonenumber);
		CustomerdetailsDBServiceImpl customerdetailsDBServiceImpl = new CustomerdetailsDBServiceImpl();
		try {
			customerlist = customerdetailsDBServiceImpl.getCustomerdetails(
					customerdetailsDTO, null, false);
			if (customerlist.size() > 0) {
				CustomerdetailsDTO customerdetailsDTO2 = customerlist.get(0);
				String securityqstId = customerdetailsDTO2
						.getSecurityquestion();
				if (questionId.equalsIgnoreCase(securityqstId)) {
					String securityans = customerdetailsDTO2
							.getSecurityanswer();
					if (questionAUnswer.equalsIgnoreCase(securityans)) {
						res = true;
					} else {
						res = false;
					}

				} else {
					res = false;

				}

			} else {
				res = false;
			}

		} catch (DBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			res = false;
		}

		return res;
	}

	public boolean cutomerOTPInsert(
			OTPMobileNoRequestBean otpMobileNoRequestBean) {
		System.out.println("Inside customer otp");
		// CustomerotpDBService customerotpDBService;

		CustomerotpDTO customerdetails = new CustomerotpDTO();
		// customerdetails.setMobilenumber(9953503835l);
		System.out
				.println("Otp number" + otpMobileNoRequestBean.getOtpNumber());
		customerdetails.setOtp(otpMobileNoRequestBean.getOtpNumber());
		customerdetails.setMobilenumber(otpMobileNoRequestBean
				.getMobileNumber());
		customerdetails.setDatetime(new Timestamp(new Date().getTime()));
		customerdetails.setPlatform(otpMobileNoRequestBean.getPlatform());
		CustomerotpDTO customerotp = new CustomerotpDTO();
		customerotp.setMobilenumber(customerdetails.getMobilenumber());
		//customerotp.setAuthkey(authkey);
		//customerotp.setPlatform(customerdetails.getPlatform());
		CustomerotpDTO customerotpDTOTargetData = new CustomerotpDTO();
		customerotpDTOTargetData.setOtp(customerdetails.getOtp());
		customerotpDTOTargetData.setPlatform(customerdetails.getPlatform());
		try {
			CustomerotpDBServiceImpl cusimpl = new CustomerotpDBServiceImpl();
			List<CustomerotpDTO> customerotpDTOs = cusimpl.getCustomerotp(
					customerotp, null, false);
			if (customerotpDTOs.size() > 0) {
				System.out.println("Inside update");
				int i = new CustomerotpDBServiceImpl().updateCustomerotp(
						customerotpDTOTargetData, customerotp, null, false);
				//System.out.println("List :" + customerotpDTOs);
			} else {
				System.out.println("Inside insert");
				customerdetails.setAuthkey(otpMobileNoRequestBean.getAuthKey());
				long i = cusimpl.insertSingleCustomerotp(customerdetails);
				System.out.println("Inser value :" + i);
			}
			// long i = new
			// CustomerotpDBServiceImpl().insertSingleCustomerotp(customerdetails);

			// System.out.println("I :"+i);
		} catch (DBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;

		/*
		 * CustomerotpDTO customerotpDTO = new CustomerotpDTO();
		 * System.out.println
		 * ("Mobile number :"+otpMobileNoRequestBean.getMobileNumber());
		 * System.out.println("Otp "+otpMobileNoRequestBean.getOtpNumber());
		 * CustomerotpDTO customerotpDTO2 = new CustomerotpDTO();
		 * customerotpDTO2
		 * .setMobilenumber(otpMobileNoRequestBean.getMobileNumber()); try {
		 * CustomerotpDBServiceImpl cusimpl = new CustomerotpDBServiceImpl();
		 * List<CustomerotpDTO> customerotpDTOs =
		 * cusimpl.getCustomerotp(customerotpDTO2, null, false); CustomerotpDTO
		 * customerotpDTO3 = customerotpDTOs.get(0); if(customerotpDTOs.size() >
		 * 0){ customerotpDTO.setOtp(otpMobileNoRequestBean.getOtpNumber()); int
		 * i = customerotpDBService.updateCustomerotp(customerotpDTO,
		 * customerotpDTO2, null, false);
		 * System.out.println("Update Customer OTP"); }else{
		 * customerotpDTO.setOtp(otpMobileNoRequestBean.getOtpNumber());
		 * customerotpDTO
		 * .setMobilenumber(otpMobileNoRequestBean.getMobileNumber()); long i =
		 * customerotpDBService.insertSingleCustomerotp(customerotpDTO);
		 * System.out.println("Insert Customer OTP"); } return true;
		 * 
		 * } catch (DBException e1) { // TODO Auto-generated catch block
		 * e1.printStackTrace(); return false; }
		 */

	}

	public boolean verifyOTPService(
			OTPMobileNoRequestBean otpMobileNoRequestBean) {
		boolean status = true;
		CustomerotpDTO customerotpDTO = new CustomerotpDTO();
		customerotpDTO.setOtp(otpMobileNoRequestBean.getOtpNumber());
		customerotpDTO
				.setMobilenumber(otpMobileNoRequestBean.getMobileNumber());
		// this.customerdetailsDBService.getCustomerdetails(customerdetails,
		// optionalQuery, useOnlyOptionalQueryFlag)
		CustomerotpDBServiceImpl customerimpl = new CustomerotpDBServiceImpl();
		try {
			List<CustomerotpDTO> list= customerimpl.getCustomerotp(customerotpDTO, null, false);
			if(list.size() > 0){
				status = true;
			}else{
				status = false;
			}
		} catch (DBException e) {
			status = false;
			e.printStackTrace();
		}
		
		
		return status;

	}

	public int generateOTP() {
		int maximum = 9999;
		int minimum = 1000;
		return ((int) (Math.random() * (maximum - minimum))) + minimum;
	}

	public String sendSms(String destination_number, String message) {
		BufferedReader rd = null;
		HttpURLConnection conn = null;
		String sms_status = "success";
		try {
			String msisdn = destination_number;
			String msg = message;
			String encodedMsg = java.net.URLEncoder.encode(msg, "UTF-8");
			String url_str = "http://54.225.97.53/bluestar/sms/sendlongsms.php?user_id=bluestar&password=bluestar1015&message=";
			String urlsrt2 = encodedMsg + "&mobile_number=+91" + msisdn;
			ApplicationLogger.info("url_str server " + url_str + urlsrt2);
			URL url2 = new URL(url_str + urlsrt2);
			Logger httpLogger = Logger
					.getLogger("sun.net.www.protocol.http.HttpURLConnection");
			httpLogger.setLevel(Level.ALL);
			System.out.println("SMS Tech APP url :" + url2);
			conn = (HttpURLConnection) url2.openConnection();
			System.out.println("Connection Created");
			conn.setRequestMethod("GET");
			System.out.println("Connection Created GET");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setUseCaches(false);
			conn.connect();
			System.out.println("Connected GET");
			rd = new BufferedReader(
					new InputStreamReader(conn.getInputStream()));
			String line;
			StringBuffer buffer = new StringBuffer();
			while ((line = rd.readLine()) != null) {
				buffer.append(line).append("\n");
			}
			System.out.println(buffer.toString());
			rd.close();
			conn.disconnect();
		} catch (IOException e) {
			sms_status = "error sms";
			ApplicationLogger
					.error("I/o Exception Occured in Sending SMS " + e);
		} catch (Exception e) {
			sms_status = "error sms";
			ApplicationLogger.error("Exception Occured in Sending SMS " + e);
		} finally {

			try {
				rd.close();
			} catch (IOException e) {
				ApplicationLogger.error("Error Closing the Stream " + e);

			}
			conn.disconnect();
		}
		return sms_status;
	}
	
	public List<StatusTrackingBean> getStatusTracking(StatusTrackingBean statusTrackingBean) throws Exception {

	    List<StatusTrackingBean> statusTrackingList = new ArrayList<StatusTrackingBean>();

	    if (statusTrackingList != null) {

	     List<Map<String, Object>> statusTrackingL1ist = new TicketAllDBServiceImpl()
	       .getStatusTracking(statusTrackingBean.getTicketNumber());

	     if (statusTrackingL1ist != null && statusTrackingL1ist.size() > 0) {

	      for (Map<String, Object> statusTrackingMap : statusTrackingL1ist) {

	       if (statusTrackingMap != null && statusTrackingMap.size() > 0 && !statusTrackingMap.isEmpty()) {

	        statusTrackingBean = new StatusTrackingBean();

	        for (Map.Entry<String, Object> entry : statusTrackingMap.entrySet()) {

	         if (entry.getKey() != null && entry.getValue() != null) {
	          if (entry.getKey().equalsIgnoreCase("TICKETNUMBER"))
	           statusTrackingBean.setTicketNumber((String)entry.getValue());
	          else if (entry.getKey().equalsIgnoreCase("productId"))
	           statusTrackingBean.setProductId((Integer)entry.getValue());
	          else if(entry.getKey().equalsIgnoreCase("productName"))
	           statusTrackingBean.setProductName((String) entry.getValue());
	          else if(entry.getKey().equalsIgnoreCase("ProgressStatus"))
	           statusTrackingBean.setProgressStatus((String) entry.getValue());
	          else if(entry.getKey().equalsIgnoreCase("UPDATEDON"))
	           statusTrackingBean.setLastUpdatedDate(String.valueOf(entry.getValue()));   
	         }
	        }
	       }

	       statusTrackingList.add(statusTrackingBean);
	      }
	     }

	     if (statusTrackingList != null && statusTrackingList.size() > 0) {

	      System.out.println(statusTrackingList.size());
	      return statusTrackingList;
	     }

	    }

	    return null;
	   }
	/*public StatusTrackingBean getStatusTracking(String MobileNumber, String ticketnumber) throws Exception {

		TicketDTO ticketDTO = new TicketDTO();
		ticketDTO.setTicketnumber(ticketnumber);
		TicketDBServiceImpl ticketDBServiceImpl = new TicketDBServiceImpl();
		StatusTrackingBean statusTrackingBean = new StatusTrackingBean();

		StatusmasterDTO statusmasterDTO = new StatusmasterDTO();
		StatusmasterDBServiceImpl statusmasterDBServiceImpl = new StatusmasterDBServiceImpl();
		TicketdetailsDTO ticketdetailsDTO = new TicketdetailsDTO();
		TicketdetailsDBServiceImpl ticketdetailsDBServiceImpl = new TicketdetailsDBServiceImpl();
		ProductmasterDTO productmasterDTO = new ProductmasterDTO();
		ProductmasterDBServiceImpl productmasterDBServiceImpl = new ProductmasterDBServiceImpl();
		List<TicketDTO> list;
		List<TicketdetailsDTO> listticketDetails;
		List<StatusmasterDTO> listStatusMaste;
		List<ProductmasterDTO> listProductmaster;
		try {
			String query="SELECT  td.PRODUCT_ID as productId ,pm.PRODUCTNAME as productName, stm.STATUSDESCRIPTION as ProgressStatus "+
                    "FROM SERVEIT.TICKET t ,SERVEIT.TICKETDETAILS td, SERVEIT.STATUSMASTER  stm,SERVEIT.PRODUCTMASTER pm  "
                    + "WHERE t.TICKET_ID=td.TICKET_ID AND  stm.STATUS_ID = td.STATUS_ID AND  pm.PRODUCT_ID=td.PRODUCT_ID "+ 
                    	"and t.TICKETNUMBER = 'B1104290002' ORDER BY updatedon DESC ORDER BY updatedon DESC fetch first 1 row ONLY";

			list = ticketDBServiceImpl.getTicket(ticketDTO, null, false);
			ticketdetailsDTO.setTicketId((int) list.get(0).getTicketId());
			listticketDetails = ticketdetailsDBServiceImpl.getTicketdetails(ticketdetailsDTO, null, false);
			statusmasterDTO.setStatusId(listticketDetails.get(0).getStatusId());
			listStatusMaste = statusmasterDBServiceImpl.getStatusmaster(statusmasterDTO, null, false);
			productmasterDTO.setProductId(listticketDetails.get(0).getProductId());
			listProductmaster = productmasterDBServiceImpl.getProductmaster(productmasterDTO, null, false);
			String productName = listProductmaster.get(0).getProductname();
			String stD = listStatusMaste.get(0).getStatusdescription();
			statusTrackingBean.setProgressStatus(stD);
			statusTrackingBean.setProductId(listticketDetails.get(0).getProductId());
			statusTrackingBean.setProductName(productName);
			statusTrackingBean.setProgressStatus(listStatusMaste.get(0).getStatusdescription());
			statusTrackingBean.setTicketNumber(ticketnumber);
			System.out.println("Ticket Number" + statusTrackingBean.getTicketNumber());
			System.out.println("Product Name---" + statusTrackingBean.getProductName());
			System.out.println("ProgressStatus==========" + statusTrackingBean.getProgressStatus());
		} catch (Exception e) {
			System.out.println("exception " + e);
		}
		// TicketDTO ticketDTO2 = list.get(0);

		return statusTrackingBean;

	}*/
	
	public TicketBean generateTicket(String MobileNumber, int productId,
			String platform) throws CustomerNotFoundException,
			ProductNotFoundException, Exception {
		CustomerdetailsDBServiceImpl customerdetailsDBServiceImpl = new CustomerdetailsDBServiceImpl();
		ProductmasterDBServiceImpl productmasterDBServiceImpl = new ProductmasterDBServiceImpl();
		TicketdetailsDBServiceImpl ticketdetailsDBServiceImpl = new TicketdetailsDBServiceImpl();
		/*System.out.println("Mobile number :"+MobileNumber);
		System.out.println("Productid :"+productId);
		System.out.println("Platform :"+platform);*/
		CustomerdetailsDTO dtoCus = new CustomerdetailsDTO();
		dtoCus.setMobile(MobileNumber);
		List<CustomerdetailsDTO> dtos;
		CustomerdetailsDTO customer = new CustomerdetailsDTO();
		CustomerdetailsDTO customerdetailsDTO = new CustomerdetailsDTO();
		String pincode = null;
		
		try {
			System.out.println("Mobile number :"+dtoCus.getMobile());
			dtos = customerdetailsDBServiceImpl.getCustomerdetails(dtoCus,null, false);
			if (dtos == null || dtos.size() == 0) {
				
				throw new CustomerNotFoundException("Customer not found");
			}
			customerdetailsDTO = dtos.get(0);
			customer = dtos.get(0);
			pincode = customerdetailsDTO.getPincode();
		} catch (DBException e) {
			throw new CustomerNotFoundException("Customer not found");
			// e.printStackTrace();
		}
		ProductmasterDTO productmasterDTO = new ProductmasterDTO();
		productmasterDTO.setProductId(productId);
		List<ProductmasterDTO> productmasters;
		int productid;
		ProductmasterDTO product = new ProductmasterDTO();
		try {
			productmasters = productmasterDBServiceImpl.getProductmaster(
					productmasterDTO, null, false);
			if (productmasters == null || productmasters.size() == 0) {
				throw new ProductNotFoundException("Product not found");
			}
			product = productmasters.get(0);
			productid = product.getProductId();
		} catch (DBException e) {
			throw new ProductNotFoundException("Product not found");
			// e.printStackTrace();
		}

		TicketdetailsDTO dto = new TicketdetailsDTO();
		//dto.setTicketId(Utilities.generateTicketId());
		//dto.setTicketdetailsId(Utilities.generateTicketId());
		/*dto.setTicketId(4936571);
		dto.setStatusId(1003);
		dto.setRemarks(null);
		dto.setTicketactionId(1034);
		dto.setDealerId(11684);
		dto.setUpdatedby(customer.getCustomername());
		dto.setUpdatedon(new Timestamp(System.currentTimeMillis()));
		dto.setExpecteddoc(null);
		dto.setExpectedtoc(null);
		dto.setCorporateescalation("F");
		dto.setActive("T");
		dto.setSdeId(7874);
		dto.setDivisionId(11684);
		dto.setBranchId(21);
		dto.setModelId(1536);
		dto.setProductId(productid);*/
		long l = ticketdetailsDBServiceImpl.insertSingleTicketdetails(dto);
		if (l > 0) {
			TicketdetailsDTO ticketS = new TicketdetailsDTO();
			ticketS.setTcktId((int) l);
			List<TicketdetailsDTO> ticketDTOs = ticketdetailsDBServiceImpl
					.getTicketdetails(ticketS, null, false);
			TicketdetailsDTO ticketDTO2 = ticketDTOs.get(0);
			TicketBean ticketBean = this.ticketAdaptar
					.TicketDTOtoBean(ticketDTO2);
			ticketBean.setProductName(product.getProductname());
			return ticketBean;
		}
		return null;
	}
	
	public Ticket generateTicketNew(String MobileNumber, int productId,
			String platform,boolean IsForcefullyGenerated) throws CustomerNotFoundException,
			ProductNotFoundException, Exception {
		TicketDBServiceImpl service = new TicketDBServiceImpl();
		TicketdetailsDBServiceImpl ticketdetailsDBServiceImpl = new TicketdetailsDBServiceImpl();
		Ticket ticket = new Ticket();
		
		String ticketNumber = "";
		try {
			
			String insertSuccess = "";
			// Added by IBM, starts
			int ibaseId;
			// Added by IBM, ends
			boolean sdeAvailable = false;
			boolean branchAvailable = false;
			boolean transaction = false;
			boolean divisionAvailable = false;
			String statusMsgs = "";
			String createdTicketNumber = null;
			int dealerID = 0;
			int retailer_Id = 0;
			String callTypeDesc = null;
			String retailerId = null;
			// Added for Retail Cr #12
			int callLogicAllocationId = 0;
			int sdeId = 0;
			// Added for Retail Cr #12

			TicketCreationDTO createTicketDetails = new TicketCreationDTO();
			CommunicationDetailsDTO communicationDetails = new CommunicationDetailsDTO();
			// Added for Call Type CR, starts
			RetailerMasterDTO retailerTicketDetails = new RetailerMasterDTO();

			System.out.println("Call Logging process Action method called ");
			// Code added by IBM, starts
			transaction = true;
			// Code added by IBM, ends

			// Code added for Retailer CR,starts
			retailerTicketDetails = new RetailerMasterDTO();
			retailerTicketDetails.setRetailerName("retailer");
			retailerTicketDetails.setRetailerCategory("Unknown");
			retailerTicketDetails.setLocation((""));
			retailerTicketDetails.setCity("");
			retailerTicketDetails.setContactPerson("Manohar");
			retailerTicketDetails.setLandlineNo("");
			retailerTicketDetails.setMobileNo("9555083523");
			retailerTicketDetails.setEmailId("vlink3@bluestarindia.com");
			retailerId = "";
			if (retailerId == null || retailerId.equals("")) {
				retailer_Id = 0;
				retailerTicketDetails.setRetailer_id(retailer_Id);
			} else {
				retailerId = retailerId.trim();
				retailer_Id = 0;
				retailerTicketDetails.setRetailer_id(retailer_Id);
			}

			// Code added for Retailer CR,ends
			transaction = true;

			createTicketDetails = CallLoggingHelper.setRequestParameters(MobileNumber, productId,
					createTicketDetails);

			System.out.println("SDE ID is " + createTicketDetails.getSdeId());
			System.out.println("Division ID: "
					+ createTicketDetails.getDivisionid() + ", Branch ID : "
					+ createTicketDetails.getBranchid());

			if (createTicketDetails.getScenarionumber().equals("1")) {
				System.out.println("Creating ticket for Scenario 1");
				System.out.println("DealerID : "
						+ createTicketDetails.getDealerId());

				System.out.println("In check for scenario # 1 SDE_ID is "
						+ createTicketDetails.getSdeId());
				if (createTicketDetails.getSdeId() == 0) {
					// Find SDE for Div 52 logic
					if (createTicketDetails.getDivisionid() == GenericConstants.DIVISON_RAPIDSERVICE) {
						try {
//							sdeId = retrieveBusinessService.getSDEForRetailTicket(
//									createTicketDetails.getDivisionid(),
//									createTicketDetails.getPincode());
							sdeId = 8722;

							if (sdeId > 0) {
								createTicketDetails.setSdeId(sdeId);
								// System.out.println("!!!!!!!!!!!!  Setting SDE ID as "+createTicketDetails.getSdeId());
							} else {
								// System.out.println("!!!!!!!!!!!! No SDE Found ");
							}

						} catch (Exception e1) {
							ApplicationLogger
									.debug("Unknown Exception occurred: while getting SDE(mapped to DIVISION_ID+PINCODE) for 52-RAPID SERVICE "
											+ e1);
						}
					}

					if (sdeId == 0) {
						try {
//							createTicketDetails.setSdeId(retrieveBusinessService
//									.getSdeId(createTicketDetails.getBranchid(),
//											createTicketDetails.getDivisionid()));
							sdeId = 8722;
						} catch (Exception e) {
							ApplicationLogger.error("Unknown Exception occurred "
									+ e);
							 System.out.println(
									"Unknown Exception while retreiving sde id");
							
							throw e;
						}
					}

				}

				if (createTicketDetails.getDivisionid() == GenericConstants.DIVISON_RAPIDSERVICE) {
					int pincode = createTicketDetails.getPincode();
					if (createTicketDetails.getDealerId() == 0) {
						if (pincode != 0) {
							int dealer_id = 0;
							try {
//								dealer_id = retrieveBusinessService
//										.getDealerFromPincode(pincode);
								dealer_id = 11316;
							} catch (Exception e) {
								ApplicationLogger
										.debug("Unknown Exception occurred: cannot dispatch to Dealer for 52-RAPID SERVICE "
												+ e);
							}

							if (dealer_id == 0) {

								FranchiseeDetailsDTO franchiseeDetailsDTO = new FranchiseeDetailsDTO();

								franchiseeDetailsDTO
										.setDivisionId(createTicketDetails
												.getDivisionid());
								franchiseeDetailsDTO.setPincode(createTicketDetails
										.getPincode());
								franchiseeDetailsDTO
										.setCallTypeId(createTicketDetails
												.getCallTypeId());
								franchiseeDetailsDTO
										.setBranchId(createTicketDetails
												.getBranchid());

								if (retailerId != null) {
									try {
										franchiseeDetailsDTO.setRetailerId(Integer
												.parseInt(retailerId));
									} catch (Exception ex) {
										ApplicationLogger
												.error(" Caught Exception while parsing Retailer "
														+ ex);
									}
								} else {
									// do nothing
								}
								franchiseeDetailsDTO
										.setProductGroupId(createTicketDetails
												.getProductgroupid());

								try {
//									franchiseeDetailsDTO = retrieveBusinessService
//											.getFranchiseeForTicket(franchiseeDetailsDTO);
									ApplicationLogger
											.error(" Got Franchisee id as "
													+ franchiseeDetailsDTO
															.getFranchiseeId());
									dealer_id = franchiseeDetailsDTO
											.getFranchiseeId();
									ApplicationLogger
											.error(" Got Logic Allocation Id as "
													+ franchiseeDetailsDTO
															.getLogicAllocationId());
									callLogicAllocationId = franchiseeDetailsDTO
											.getLogicAllocationId();
								} catch (Exception e) {
									ApplicationLogger
											.error(" Caught Exception while seraching for Franchisee :: "
													+ e);
									e.printStackTrace();
								}
							}
							// Added for Retail CR 12, ends

							createTicketDetails.setDealerId(dealer_id);
							createTicketDetails
									.setCallLogicAllocationId(callLogicAllocationId);

							System.out.println("Dealer ID ** " + dealer_id);

							int statusid = 0;
							try {
//								statusid = retrieveBusinessService.getStatusId(
//										createTicketDetails.getDealerId(),
//										request.getParameter("requestedaction"));
								statusid = 1001;
								// Code added by IBM,
								// StatusConstants.T_DISPATCHED used instead
								// of Hard coding, starts
								if (statusid == StatusConstants.T_DISPATCHED)
									// Code added by IBM,
									// StatusConstants.T_DISPATCHED used
									// instead of Hard coding, ends
									createTicketDetails
											.setStatuscode(StatusConstants.DISPATCHED);
							} catch (Exception e) {
								ApplicationLogger
										.error("Unknown Exception occurred " + e);
								 System.out.println(
										"Unknown Exception while retreiving status id");
								throw e;
							}
							createTicketDetails.setStatusId(statusid);
						}

					}

				}

				/*
				 * Special condition for division ACPD service. Applicable for all
				 * scenarios If the ticket belongs to this Product-Group/Product and
				 * if Dealer is not attached,SDE should play the role of dealer
				 * Logic implemented: 1.Take the EMPLOYEEID from
				 * SDEBRANCHDIVISIONMAP for that ticket 2.SELECT PARTNERCODE from
				 * EMPLOYEEMASTER where EMPLOYEEID=the value you got from (1). Lets
				 * call this value ABC 3.SELECT DEALER_ID from DEALERMASTER where
				 * DEALERCODE=ABC 4.Set status of Call to DISPATCHED and assign this
				 * Dealer to the ticket
				 */
				else if (createTicketDetails.getSdeId() != 0) {
					for (int i = 0; i < GenericConstants.PRODUCTS.length; i++) {
						if (createTicketDetails.getProductid() == GenericConstants.PRODUCTS[i]) {
							int dealer_id = 0;
							if (createTicketDetails.getDealerId() == 0) {

								try {
//									dealer_id = retrieveBusinessService
//											.getDealerFromSDE(createTicketDetails
//													.getSdeId());
									dealer_id = 11316;
								} catch (Exception e) {
									ApplicationLogger
											.debug("Unknown Exception occurred: cannot dispatch to Dealer for 50-ACPD SERVICE"
													+ e);
									// Do NOTHING
								}
								createTicketDetails.setDealerId(dealer_id);
								ApplicationLogger
										.debug("Dealer ID ** for ACPD division "
												+ dealer_id);

								int statusid = 0;
								try {
//									statusid = retrieveBusinessService
//											.getStatusId(
//													createTicketDetails
//															.getDealerId(),
//													request.getParameter("requestedaction"));
									statusid  = 1001;
									if (statusid == StatusConstants.T_DISPATCHED)
										createTicketDetails
												.setStatuscode(StatusConstants.DISPATCHED);
								} catch (Exception e) {
									ApplicationLogger
											.error("Unknown Exception occurred "
													+ e);
									 System.out.println(
											"Unknown Exception while retreiving status id");
									throw e;
									
								}
								createTicketDetails.setStatusId(statusid);
							}
							break;
						}
					}

				}

				if (createTicketDetails.getSdeId() != 0) {
					sdeAvailable = true;
					branchAvailable = true;
					try {
						insertSuccess = ticketdetailsDBServiceImpl.saveTicket(
								createTicketDetails, retailerTicketDetails,IsForcefullyGenerated);
						createdTicketNumber = createTicketDetails.getTicketnumber();
//						insertSuccess = retrieveBusinessService.saveTicket(
//								createTicketDetails, retailerTicketDetails);
						createdTicketNumber = createTicketDetails.getTicketnumber();
						ticketNumber = insertSuccess;
						com.juv.bluestar.common.db.model.TicketBean bean = new com.juv.bluestar.common.db.model.TicketBean();
						bean = ticketdetailsDBServiceImpl.getTicketDetails(insertSuccess);
						// Ticket Bean to Ticket
						if(bean != null){
							ticket.setTicketNumber(bean.getTicketNumber());
							ticket.setUpdatedOn(bean.getUpdatedOn());
							ticket.setProductId(bean.getProductId());
							ticket.setProductName(bean.getProductName());
							ticket.setStatus(bean.getStatus());
						}
						
						
						System.out.println("%%%%%%%%%%%%%%%%%% :"+insertSuccess);
						System.out.println(" %%%%%%%%%%%%%%%%  "
								+ createTicketDetails.getStatuscode() + "        "
								+ createTicketDetails.getStatusId());
						if (createTicketDetails != null) {
							if (createTicketDetails.getStatusId() != CALL_CLOSE_STATUS_ID) {
								//CommunicationHelper.sendEmail(createTicketDetails);
							}
						}

						System.out.println("Ticket created successfully");
						ApplicationLogger
								.info("Details of ticket generated\nTicketNumber: "
										+ createTicketDetails.getTicketnumber()
										+ "Created by: "
										+ createTicketDetails.getCreatedby());
					} catch (Exception e) {
						ApplicationLogger
								.error("Unknown Exception occurred while saving ticket for scenario 1 "
										+ e);
						 System.out.println(
								"Unknown Exception while creating ticket for scenario 2 ");
						throw e;
						
					}
				} else {
					insertSuccess = "";
					sdeAvailable = false;
					if (createTicketDetails.getBranchid() == 0)
						branchAvailable = false;
					else
						branchAvailable = true;
					if (createTicketDetails.getDivisionid() == 0)
						divisionAvailable = false;
					else
						divisionAvailable = true;
					ApplicationLogger
							.info("Ticket cannot be created because there is no SDE mapped for branch and division "
									+ createTicketDetails.getBranchid()
									+ " "
									+ createTicketDetails.getDivisionid());
				}
			}
			// Code added by IBM, Constant used instead of value
			// 2,TicketScenario.NO_COMPONENT_SCENARIO, starts
			else if (createTicketDetails.getScenarionumber().equals(
					TicketScenario.NO_COMPONENT_SCENARIO))
			// Code added by IBM, Constant used instead of value
			// 2,TicketScenario.NO_COMPONENT_SCENARIO, ends
			{/*
				// System.out.println("Creating ticket for Scenario 2 SDE is "+createTicketDetails.getSdeId());
				if (createTicketDetails.getSdeId() == 0) {

					// Find SDE for Division # 52,starts
					// Find SDE for Div 52 logic
					if (createTicketDetails.getDivisionid() == GenericConstants.DIVISON_RAPIDSERVICE) {
						try {
							sdeId = retrieveBusinessService.getSDEForRetailTicket(
									createTicketDetails.getDivisionid(),
									createTicketDetails.getPincode());

							if (sdeId > 0) {
								createTicketDetails.setSdeId(sdeId);
								// System.out.println("!!!!!!!!!!!!  Setting SDE ID as "+createTicketDetails.getSdeId());
							} else {
								// System.out.println("!!!!!!!!!!!! No SDE Found ");
							}

						} catch (Exception e1) {
							ApplicationLogger
									.debug("Unknown Exception occurred: while getting SDE(mapped to DIVISION_ID+PINCODE) for 52-RAPID SERVICE "
											+ e1);
						}
					}
					// Find SDE for Div 52 logic ends

					if (sdeId == 0) {
						try {
							createTicketDetails.setSdeId(retrieveBusinessService
									.getSdeId(createTicketDetails.getBranchid(),
											createTicketDetails.getDivisionid()));
						} catch (Exception e) {
							ApplicationLogger.error("Unknown Exception occurred "
									+ e);
							 System.out.println(
									"Unknown Exception while retreiving sde id");
							throw e;
							
						}
					}

				}

				ApplicationLogger.error("Creating ticket for Scenario 2  1");
				// Code Changed by IBM, starts
				
				 * Special condition for division ACPD service. Applicable for all
				 * scenarios If the ticket belongs to this Product-Group/Product and
				 * if Dealer is not attached,SDE should play the role of dealer
				 * Logic implemented: 1.Take the EMPLOYEEID from
				 * SDEBRANCHDIVISIONMAP for that ticket 2.SELECT PARTNERCODE from
				 * EMPLOYEEMASTER where EMPLOYEEID=the value you got from (1). Lets
				 * call this value ABC 3.SELECT DEALER_ID from DEALERMASTER where
				 * DEALERCODE=ABC 4.Set status of Call to DISPATCHED and assign this
				 * Dealer to the ticket
				 
				if (createTicketDetails.getSdeId() != 0) {
					for (int i = 0; i < GenericConstants.PRODUCTS.length; i++) {

						ApplicationLogger.error(" Product is  "
								+ GenericConstants.PRODUCTS[i] + "    "
								+ createTicketDetails.getProductid());
						if (createTicketDetails.getProductid() == GenericConstants.PRODUCTS[i]) {
							int dealer_id = 0;
							// Added to get dealer from auto-complete
							dealer_id = createTicketDetails.getDealerId();
							if (createTicketDetails.getDealerId() == 0) {
								// -----end-------------
								try {
									dealer_id = retrieveBusinessService
											.getDealerFromSDE(createTicketDetails
													.getSdeId());
								} catch (Exception e) {
									ApplicationLogger
											.debug("Unknown Exception occurred: cannot dispatch to Dealer for 50-ACPD SERVICE"
													+ e);
									// Do NOTHING
								}
							}
							createTicketDetails.setDealerId(dealer_id);
							ApplicationLogger
									.debug("Dealer ID ** for ACPD division "
											+ dealer_id);

							int statusid = 0;
							try {
								statusid = retrieveBusinessService.getStatusId(
										dealer_id,
										request.getParameter("requestedaction"));
								if (statusid == StatusConstants.T_DISPATCHED)
									createTicketDetails
											.setStatuscode(StatusConstants.DISPATCHED);
							} catch (Exception e) {
								ApplicationLogger
										.error("Unknown Exception occurred " + e);
								 System.out.println(
										"Unknown Exception while retreiving status id");
								throw e;
								
							}
							createTicketDetails.setStatusId(statusid);

							break;
						}
					}

				}

				ApplicationLogger.error("Creating ticket for Scenario 2  2");

				if (createTicketDetails.getSdeId() != 0) {
					sdeAvailable = true;
					branchAvailable = true;
					divisionAvailable = true;
					try {

						// Added for Retail CR 12, starts
						if (createTicketDetails.getDivisionid() == GenericConstants.DIVISON_RAPIDSERVICE) {
							// ApplicationLogger.error(" ^^^^^^ Scenario #2 dealer id is "+dealerID);

							
							 * ApplicationLogger.error(" %%%% Division is  "+
							 * createTicketDetails.getDivisionid()+" \n" +
							 * "   PinCode is   "
							 * +createTicketDetails.getPincode()+"  \n " +
							 * "   Call Type is  "
							 * +createTicketDetails.getCallTypeId()+"  \n "+
							 * "   Retailer is "+retailerId+"  \n " +
							 * "   Product Group  is   "
							 * +createTicketDetails.getProductgroupid());
							 
							System.out.println("----Dealer ID "+createTicketDetails.getDealerId());
							if (createTicketDetails.getDealerId() == 0) {
								System.out.println("Dealer ID fetch start");
								FranchiseeDetailsDTO franchiseeDetailsDTO = new FranchiseeDetailsDTO();

								franchiseeDetailsDTO
										.setDivisionId(createTicketDetails
												.getDivisionid());
								franchiseeDetailsDTO.setPincode(createTicketDetails
										.getPincode());
								franchiseeDetailsDTO
										.setCallTypeId(createTicketDetails
												.getCallTypeId());
								franchiseeDetailsDTO
										.setBranchId(createTicketDetails
												.getBranchid());

								if (retailerId != null && !retailerId.equals("")) {
									try {
										franchiseeDetailsDTO.setRetailerId(Integer
												.parseInt(retailerId));
									} catch (Exception ex) {
										ApplicationLogger
												.error(" Caught Exception while parsing Retailer "
														+ ex);
									}
								} else {
									// do nothing
								}
								franchiseeDetailsDTO
										.setProductGroupId(createTicketDetails
												.getProductgroupid());

								int statusid = 0;

								try {
									franchiseeDetailsDTO = retrieveBusinessService
											.getFranchiseeForTicket(franchiseeDetailsDTO);
									ApplicationLogger
											.error(" Got Franchisee id as "
													+ franchiseeDetailsDTO
															.getFranchiseeId());
									dealerID = franchiseeDetailsDTO
											.getFranchiseeId();
									ApplicationLogger
											.error(" Got Logic Allocation Id as "
													+ franchiseeDetailsDTO
															.getLogicAllocationId());
									callLogicAllocationId = franchiseeDetailsDTO
											.getLogicAllocationId();

									createTicketDetails.setDealerId(dealerID);
									createTicketDetails
											.setCallLogicAllocationId(callLogicAllocationId);
								} catch (Exception e) {
									ApplicationLogger
											.error(" Caught Exception while seraching for Franchisee :: "
													+ e);
									e.printStackTrace();
								}
							}
							// commented for null value
							if (createTicketDetails.getDealerId() != 0) {
								dealerID = createTicketDetails.getDealerId();
								createTicketDetails.setDealerId(createTicketDetails
										.getDealerId());
								ApplicationLogger
										.error(" Dealer/ Frenchisee Id is from auto complete "
												+ createTicketDetails.getDealerId());
							}
							if (dealerID > 0) {
								ApplicationLogger
										.error(" in if dealerID>0 Setting Status id as  "
												+ StatusConstants.T_DISPATCHED);
								createTicketDetails
										.setStatusId(StatusConstants.T_DISPATCHED);
								createTicketDetails
										.setStatuscode(StatusConstants.DISPATCHED);

							}

							
							 * catch (Exception e) { ApplicationLogger.error(
							 * " Caught Exception while seraching for Franchisee :: "
							 * + e); e.printStackTrace(); }
							 

						}

						---------- If dealer given by user then status should be updated as dispatched for any division 
						int statusid = 0;
						try {
							statusid = retrieveBusinessService.getStatusId(
									createTicketDetails.getDealerId(),
									request.getParameter("requestedaction"));
							// Code added by IBM, constant added
							if (statusid == StatusConstants.T_DISPATCHED)
								createTicketDetails
										.setStatuscode(StatusConstants.DISPATCHED);
						} catch (Exception e) {
							ApplicationLogger.error("Unknown Exception occurred "
									+ e);
							 System.out.println(
									"Unknown Exception while retreiving status id");
							throw e;
							
							
						}
						createTicketDetails.setStatusId(statusid);
						// ------------end-------------------------------------
						// Added for Retail CR 12, ends

						// Code changed for Retailer CR,
						// RetailerTicketDetails added, starts
						insertSuccess = retrieveBusinessService.saveTicket(
								createTicketDetails, retailerTicketDetails);
						// ends
						// Code changed for Retailer CR, starts
						createdTicketNumber = createTicketDetails.getTicketnumber();
						// ends

						System.out.println(" %%%%%%%%%%%%%%%%  "
								+ createTicketDetails.getStatuscode() + "        "
								+ createTicketDetails.getStatusId());
						if (createTicketDetails != null) {
							if (createTicketDetails.getStatusId() != CALL_CLOSE_STATUS_ID) {
								CommunicationHelper.sendEmail(createTicketDetails);
							}
						}

						System.out.println("Ticket created successfully on "
								+ DateFormat.getDateTimeInstance().format(
										new Date()));
						ApplicationLogger
								.info("Details of ticket generated\nTicketNumber: "
										+ createTicketDetails.getTicketnumber()
										+ "Created by: "
										+ createTicketDetails.getCreatedby());
					} catch (Exception e) {
						ApplicationLogger
								.error("Unknown Exception occurred while saving ticket for scenario 2 "
										+ e);
						System.out.println(
								"Unknown Exception while saving ticket for scenario 2");
						throw e;
					}
				}

				else {
					insertSuccess = 0;
					sdeAvailable = false;
					if (createTicketDetails.getBranchid() == 0)
						branchAvailable = false;
					else
						branchAvailable = true;
					if (createTicketDetails.getDivisionid() == 0)
						divisionAvailable = false;
					else
						divisionAvailable = true;
					ApplicationLogger
							.info("Ticket cannot be created because there is no SDE mapped for branch and division "
									+ createTicketDetails.getBranchid()
									+ " "
									+ createTicketDetails.getDivisionid());
				}
			*/}

			// Constant Added by IBM, starts
			else if (createTicketDetails.getScenarionumber().equals(
					TicketScenario.NO_COMPONENT_NO_IBASE_SCENARIO))
			// Constant Added by IBM, ends
			{/*
				
				 * There is separate field set for customer details for Pseudo
				 * ticket Hence get all the pseudo customer details fields
				 
				System.out.println("Creating ticket for Scenario 3");
				createTicketDetails.setCustomername(request
						.getParameter("ccrpseudocustomername"));
				createTicketDetails.setCity(request.getParameter("ccrpseudocity"));
				createTicketDetails.setLandmark(request
						.getParameter("ccrpseudolandmark"));
				if (request.getParameter("ccrpseudopincode").length() != 0)
					createTicketDetails.setPincode(Integer.parseInt(request
							.getParameter("ccrpseudopincode")));
				createTicketDetails.setAddress(request
						.getParameter("ccrpseudoaddress"));
				createTicketDetails
						.setEmail(request.getParameter("ccrpseudoemail"));
				createTicketDetails.setMobile(request
						.getParameter("ccrpseudomobile"));
				createTicketDetails
						.setPhone(request.getParameter("ccrpseudophone"));
				createTicketDetails.setDistance(request
						.getParameter("ccrpseudodistance"));
				createTicketDetails
						.setState(request.getParameter("ccrpseudostate"));
				createTicketDetails.setSiteid(request
						.getParameter("ccrpseudositeid"));

				// ******
				
				 * In Scenario 3, branch id should be determined from either state
				 * or pincode Retrieved branch id is used for determining SDE
				 
				// check if pincode is entered by the user
				if (createTicketDetails.getPincode() != 0) {
					try {
						createTicketDetails.setBranchid(retrieveBusinessService
								.getBranchFromPincode(createTicketDetails
										.getPincode()));
						System.out.println("Branch from Pincode is : "
								+ createTicketDetails.getBranchid());
					} catch (Exception e) {
						ApplicationLogger
								.debug("Unable to retreive branch id from Pincode "
										+ createTicketDetails.getPincode());
					}
				}
				// check if state is entered by the user
			//	if (createTicketDetails.getStateid() == 0) {
					try {
						
						System.out.println("state id in Controller after "+createTicketDetails.getStateid());
						System.out.println("state name in Controller "+createTicketDetails.getState());
						createTicketDetails.setStateid(retrieveBusinessService.getStateId(createTicketDetails.getState()));
						System.out.println("state id in Controller after "+createTicketDetails.getStateid());
					} catch (Exception e) {
						ApplicationLogger
								.error("Unable to retreive state id for state "
										+ createTicketDetails.getState());
						 System.out.println(
								"Unknown Exception while retreiving state id. state id is 0 from request for sc3 ticket ");
					throw e;
					}
			//	}
				if ((createTicketDetails.getStateid() != 0)
						&& (createTicketDetails.getBranchid() == 0)) {
					System.out.println("Branch not found for pincode entered. Searching state branch map which may lead to incorrect branch assignment as a state can have more than one branch,any branch can be assigned");
					// call method to find branch id from state id
					try {
						createTicketDetails.setBranchid(retrieveBusinessService
								.getBranchFromState(createTicketDetails
										.getStateid()));
					} catch (Exception e) {
						ApplicationLogger
								.debug("Unable to retreive branch id from state id "
										+ createTicketDetails.getStateid());
					}
				}

				System.out.println("division id "
						+ createTicketDetails.getDivisionid() + "branchid "
						+ createTicketDetails.getBranchid());
				if (createTicketDetails.getBranchid() != 0) {
					try {
						createTicketDetails.setBranch(retrieveBusinessService
								.getBranchName(createTicketDetails.getBranchid()));
					} catch (Exception e1) {
						ApplicationLogger.error(
								"Unknown Exception occurred while retreiving branch name for id "
										+ createTicketDetails.getBranchid(), e1);
					}
				}
				// check if division id and branch id exists

				// get SDE for Division 52, starts
				// Find SDE for Division # 52,starts
				// Find SDE for Div 52 logic
				if (createTicketDetails.getDivisionid() == GenericConstants.DIVISON_RAPIDSERVICE) {
					try {
						sdeId = retrieveBusinessService.getSDEForRetailTicket(
								createTicketDetails.getDivisionid(),
								createTicketDetails.getPincode());

						if (sdeId > 0) {
							createTicketDetails.setSdeId(sdeId);
							// System.out.println("!!!!!!!!!!!!  Setting SDE ID as "+createTicketDetails.getSdeId());
						} else {
							// System.out.println("!!!!!!!!!!!! No SDE Found ");
						}

					} catch (Exception e1) {
						ApplicationLogger
								.debug("Unknown Exception occurred: while getting SDE(mapped to DIVISION_ID+PINCODE) for 52-RAPID SERVICE "
										+ e1);
					}

					if (sdeId == 0) {
						if ((createTicketDetails.getDivisionid() != 0)
								&& (createTicketDetails.getBranchid() != 0))
							try {
								createTicketDetails
										.setSdeId(retrieveBusinessService.getSdeId(
												createTicketDetails.getBranchid(),
												createTicketDetails.getDivisionid()));
							} catch (Exception e) {
								ApplicationLogger
										.error("Unknown Exception occurred while retreiving sde id "
												+ e);
								 System.out.println(
										"Unknown Exception while retreiving sde id ");
								throw e;
								
							}
						System.out.println("Sde id "
								+ createTicketDetails.getSdeId());
					}

				} else {
					// Find SDE for Div 52 logic ends
					// get SDE for Division 52,ends

					if ((createTicketDetails.getDivisionid() != 0)
							&& (createTicketDetails.getBranchid() != 0))
						try {
							createTicketDetails.setSdeId(retrieveBusinessService
									.getSdeId(createTicketDetails.getBranchid(),
											createTicketDetails.getDivisionid()));
						} catch (Exception e) {
							ApplicationLogger
									.error("Unknown Exception occurred while retreiving sde id "
											+ e);
							 System.out.println(
									"Unknown Exception while retreiving sde id ");
							throw e;
							
						}
					System.out.println("Sde id "
							+ createTicketDetails.getSdeId());
				}
				
				 * Special condition when division is 52-RAPID SERVICE if the dealer
				 * is not assigned in Scenario3, the dealer should be assigned
				 * through pincode dealer map
				 
				if (createTicketDetails.getDivisionid() == GenericConstants.DIVISON_RAPIDSERVICE) {
					ApplicationLogger.error("dealer in portlet manual entry "
							+ createTicketDetails.getDealerId());
					int pincode = createTicketDetails.getPincode();
					if (createTicketDetails.getDealerId() == 0) {
						if (pincode != 0) {
							int dealer_id = 0;
							try {
								dealer_id = retrieveBusinessService
										.getDealerFromPincode(pincode);
							} catch (Exception e) {
								ApplicationLogger
										.debug("Unknown Exception occurred: cannot dispatch to Dealer for 52-RAPID SERVICE "
												+ e);
							}

							// Added for Retail CR 12, starts

							ApplicationLogger
									.error(" %%%%%% Scenario #3 dealer id is "
											+ dealer_id);
							if (dealer_id == 0) {

								
								 * ApplicationLogger.error(" %%%% Division is  "+
								 * createTicketDetails.getDivisionid()+" \n" +
								 * "   PinCode is   "+createTicketDetails.
								 * getPincode()+"  \n " + "   Call Type is  "
								 * +createTicketDetails.getCallTypeId ()+"  \n "+
								 * "   Retailer is "+retailerId+"  \n " +
								 * "   Product Group  is   " +createTicketDetails
								 * .getProductgroupid());
								 

								FranchiseeDetailsDTO franchiseeDetailsDTO = new FranchiseeDetailsDTO();

								franchiseeDetailsDTO
										.setDivisionId(createTicketDetails
												.getDivisionid());
								franchiseeDetailsDTO.setPincode(createTicketDetails
										.getPincode());
								franchiseeDetailsDTO
										.setCallTypeId(createTicketDetails
												.getCallTypeId());
								franchiseeDetailsDTO
										.setBranchId(createTicketDetails
												.getBranchid());

								if (retailerId != null && !retailerId.equals("")) {
									try {
										franchiseeDetailsDTO.setRetailerId(Integer
												.parseInt(retailerId));
									} catch (Exception ex) {
										ApplicationLogger
												.error(" Caught Exception while parsing Retailer "
														+ ex);
									}
								} else {
									// do nothing
								}
								franchiseeDetailsDTO
										.setProductGroupId(createTicketDetails
												.getProductgroupid());

								try {
									franchiseeDetailsDTO = retrieveBusinessService
											.getFranchiseeForTicket(franchiseeDetailsDTO);
									ApplicationLogger
											.error(" Got Franchisee id as dealerin portlet "
													+ franchiseeDetailsDTO
															.getFranchiseeId());
									dealer_id = franchiseeDetailsDTO
											.getFranchiseeId();
									ApplicationLogger
											.error(" Got Logic Allocation Id as "
													+ franchiseeDetailsDTO
															.getLogicAllocationId());
									callLogicAllocationId = franchiseeDetailsDTO
											.getLogicAllocationId();

								} catch (Exception e) {
									ApplicationLogger
											.error(" Caught Exception while seraching for Franchisee :: "
													+ e);
									e.printStackTrace();
								}
							}
							// Added for Retail CR 12, ends

							ApplicationLogger.error("dealer from pincode logic"
									+ dealer_id);
							createTicketDetails.setDealerId(dealer_id);
							createTicketDetails
									.setCallLogicAllocationId(callLogicAllocationId);
							ApplicationLogger.error("Dealer ID ** " + dealer_id);

						}
					}
					int statusid = 0;
					try {
						statusid = retrieveBusinessService.getStatusId(
								createTicketDetails.getDealerId(),
								request.getParameter("requestedaction"));
						// Code Changed by IBM, constant added
						if (statusid == StatusConstants.T_DISPATCHED)
							createTicketDetails
									.setStatuscode(StatusConstants.DISPATCHED);
					} catch (Exception e) {
						ApplicationLogger.error("Unknown Exception occurred " + e);
						 System.out.println(
								"Unknown Exception while retreiving status id");
						throw e;
					}
					createTicketDetails.setStatusId(statusid);
					
					 * Condition to set status even when user provide dealer through
					 * auto-complete so pincodecheck,getDealerid check terminated
					 * before setting status
					 

					// Commented to implement Dealer allocation CR

				}
				
				 * Special condition for division ACPD service. Applicable for all
				 * scenarios If the ticket belongs to this Product-Group/Product and
				 * if Dealer is not attached,SDE should play the role of dealer
				 * Logic implemented: 1.Take the EMPLOYEEID from
				 * SDEBRANCHDIVISIONMAP for that ticket 2.SELECT PARTNERCODE from
				 * EMPLOYEEMASTER where EMPLOYEEID=the value you got from (1). Lets
				 * call this value ABC 3.SELECT DEALER_ID from DEALERMASTER where
				 * DEALERCODE=ABC 4.Set status of Call to DISPATCHED and assign this
				 * Dealer to the ticket
				 

				else if (createTicketDetails.getSdeId() != 0) {
					for (int i = 0; i < GenericConstants.PRODUCTS.length; i++) {
						if (createTicketDetails.getProductid() == GenericConstants.PRODUCTS[i]) {
							int dealer_id = 0;
							// Code Added by IBM, if code changed
							ApplicationLogger
									.error("from autocompletedealer for 50 acpd 15 july"
											+ createTicketDetails.getDealerId());
							dealer_id = createTicketDetails.getDealerId();
							if (createTicketDetails.getDealerId() == 0) {
								try {
									dealer_id = retrieveBusinessService
											.getDealerFromSDE(createTicketDetails
													.getSdeId());
									ApplicationLogger
											.error("dealer for 50 acpd 15 july"
													+ dealer_id);
								} catch (Exception e) {
									ApplicationLogger
											.debug("Unknown Exception occurred: cannot dispatch to Dealer for 50-ACPD SERVICE"
													+ e);
									// Do NOTHING
								}
								createTicketDetails.setDealerId(dealer_id);
								ApplicationLogger
										.debug("Dealer ID ** for ACPD division "
												+ dealer_id);

							}
							
							 * If dealer given by user then status should be updated
							 * as dispatched
							 
							int statusid = 0;
							try {
								statusid = retrieveBusinessService.getStatusId(
										dealer_id,
										request.getParameter("requestedaction"));
								// Code added by IBM, constant added
								if (statusid == StatusConstants.T_DISPATCHED)
									createTicketDetails
											.setStatuscode(StatusConstants.DISPATCHED);
							} catch (Exception e) {
								ApplicationLogger
										.error("Unknown Exception occurred " + e);
								System.out.println(
										"Unknown Exception while retreiving status id");
								throw e;
							}
							createTicketDetails.setStatusId(statusid);
						}
						break;

					}

				}
				---------- If dealer given by user then status should be updated as dispatched for any division 
				int statusid = 0;
				try {
					statusid = retrieveBusinessService.getStatusId(
							createTicketDetails.getDealerId(),
							request.getParameter("requestedaction"));
					// Code added by IBM, constant added
					if (statusid == StatusConstants.T_DISPATCHED)
						createTicketDetails
								.setStatuscode(StatusConstants.DISPATCHED);
				} catch (Exception e) {
					ApplicationLogger.error("Unknown Exception occurred " + e);
					 System.out.println(
							"Unknown Exception while retreiving status id");
					throw e;
				}
				createTicketDetails.setStatusId(statusid);
				// ------------end-------------------------------------

				if (createTicketDetails.getSdeId() != 0) {
					sdeAvailable = true;
					branchAvailable = true;
					divisionAvailable = true;
					try {
						// Code change for Retailer CR,
						// retailerTicketDetails added
						insertSuccess = retrieveBusinessService.saveTicket(
								createTicketDetails, retailerTicketDetails);
						createdTicketNumber = createTicketDetails.getTicketnumber();

						System.out.println(" %%%%%%%%%%%%%%%%  "
								+ createTicketDetails.getStatuscode() + "        "
								+ createTicketDetails.getStatusId());
						if (createTicketDetails != null) {
							if (createTicketDetails.getStatusId() != CALL_CLOSE_STATUS_ID) {
								CommunicationHelper.sendEmail(createTicketDetails);
							}
						}

						System.out.println("Ticket created successfully on "
								+ DateFormat.getDateTimeInstance().format(
										new Date()));
						ApplicationLogger
								.info("Details of ticket generated\nTicketNumber: "
										+ createTicketDetails.getTicketnumber()
										+ "Created by: "
										+ createTicketDetails.getCreatedby());
					} catch (Exception e) {
						ApplicationLogger
								.error("Unknown Exception occurred while saving ticket for scenario 3 "
										+ e);
						throw e;
					}
				} else {
					insertSuccess = 0;
					sdeAvailable = false;
					if (createTicketDetails.getBranchid() == 0)
						branchAvailable = false;
					else
						branchAvailable = true;
					if (createTicketDetails.getDivisionid() == 0)
						divisionAvailable = false;
					else
						divisionAvailable = true;
					ApplicationLogger
							.info("Ticket cannot be created because there is no SDE mapped for branch and division "
									+ createTicketDetails.getBranchid()
									+ " "
									+ createTicketDetails.getDivisionid());
				}

				ApplicationLogger
						.info("Returning after ticket Creation from portlet Class");
			*/}

			/*try {

				callTypeDesc = retrieveBusinessService
						.getCallTypeDesc(createdTicketNumber);
			} catch (Exception ex) {
				ApplicationLogger.error("Call Type Desc in request " + ex);
			}*/

			createTicketDetails.setCallTypeDesc(callTypeDesc);

			if (transaction) {/*
				request.setAttribute("createticketdetails", createTicketDetails);
				// Code changes , Retailer CR
				request.setAttribute("ticketRetailerDetails", retailerTicketDetails);
				if (insertSuccess == 1) {
					if (createTicketDetails.getStatusId() == 1015) {
						// statusMsgs =
						// "Ticket Created with status CANCELLED. Reason for Cancellation - Visit Charges not accepted.";
						// Constant added by IBM
						statusMsgs = StatusMessageConstants.SUCCESSMSGS_VNA;
					} else
						// statusMsgs =
						// "Ticket created successfully.Following are the details of the ticket";
						statusMsgs = StatusMessageConstants.SUCCESSMSGS;
					request.setAttribute("commdetails", communicationDetails);

					System.out.println("coommm "
							+ communicationDetails.getSdename());
					System.out.println("ibaseid in request "
							+ createTicketDetails.getIbaseId());

					ibaseId = createTicketDetails.getIbaseId();

					request.setAttribute("ibaseid", Integer.valueOf(ibaseId));
				}
				// Constants added
				else {
					if (!branchAvailable)
						statusMsgs = StatusMessageConstants.BRANCHUNVAIALBLEMSG;
					else if (!divisionAvailable)
						statusMsgs = StatusMessageConstants.DIVISIONUNAVALABLEMSG;
					else if (!sdeAvailable)
						statusMsgs = StatusMessageConstants.SDEUNAVALABLEMSG;
					else
						statusMsgs = StatusMessageConstants.ERRORMSGS;
				}
			*/}

			/*request.setAttribute("statusmsg", statusMsgs);
			request.setAttribute("insertsuccess", Integer.valueOf(insertSuccess));
			System.out.println("value of transaction 2May "
					+ Boolean.valueOf(transaction));
			request.setAttribute("transaction", Boolean.valueOf(transaction));*/

			createTicketDetails = null;
			// Code added by IBM
			ibaseId = 0;
			// ends
			transaction = false;
			insertSuccess = "";
			statusMsgs = "";

		
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		System.out.println("Ticket number :"+ticket.getTicketNumber());
		
		return ticket;
	}
/*	public boolean verifyOTP(CustomerOTPbean bean) {
		// TODO Auto-generated method stub
		return false;
	}*/

/*	public static void main(String[] args) {
		CustomerService service = new CustomerService();
		OTPMobileNoRequestBean otpMobileNoRequestBean = new OTPMobileNoRequestBean();
		//CustomerService service = new CustomerService();
		int i = service.generateOTP();
		System.out.println("I :" + i);
		UserBean userBean = new UserBean();
		userBean.setFirstName("sakshi");
		userBean.setLastName("girdhar");
		userBean.setEmail("sakshi.girdhar@juventussoft.com");
		String address1 ="[{\"address\" : \"Kellton tech , plot no 270\",\"locality\":\"Udyog Vihar\",\"pinCode\":\"122016\",\"city\":\"gurgaon\",\"state\":\"Haryana\"},{\"address\" : \"Xchanging, plot no 270\",\"locality\":\"Udyog Vihar\",\"pinCode\":\"122016\",\"city\":\" gurgaon\",\"state\":\"Haryana\"}]";
		//String address2 = "[{address=Kellton tech , plot no 270, locality=Udyog Vihar, pinCode=122016, city= gurgaon, state=Haryana}, {address=Xchanging, plot no 270, locality=Udyog Vihar, pinCode=122016, city= gurgaon, state=Haryana}]";
		//ArrayList<Object> addresslist = new ArrayList<Object>();
		//addresslist.add(address2);
		//addresslist.add(0, address2);
		//userBean.setAddresses(address2);
		//userBean.setPin("123456");
		//userBean.setSecurityQuestionAnswer("");
		userBean.setSecurityQuestionId("What is your Greeting");
		CustomerService customerService = new CustomerService();
		try {
			boolean res = customerService.registerUser(userBean, "8800253402");
			System.out.println("Response :"+res);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		CustomerdetailsDTO customerdetails=new CustomerdetailsDTO();
		customerdetails.setMobile("8800253402");
		customerdetails.setCustomername("Laxmi");

		// String a = service.sendSms(String.valueOf(bean.getMobileNumber()),
		// String.valueOf(bean.getOtpNumber()));
		List<CustomerotpDTO> a = null;
		try {
			CustomerService customerService = new CustomerService();
			
			boolean sta = customerService.verifyOTPService(otpMobileNoRequestBean);
			
			CustomerdetailsDBServiceImpl customerdetailsDBServiceImpl =new CustomerdetailsDBServiceImpl();
			customerdetailsDBServiceImpl.insertSingleCustomerdetails(customerdetails);
			System.out.println("Status :"+sta);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
	public Ticket abc(String ticketNumber) throws CustomerNotFoundException,
	ProductNotFoundException, Exception{
		Ticket ticket = new Ticket();
		TicketdetailsDBServiceImpl dbServiceImpl = new TicketdetailsDBServiceImpl();
		try {
			
			com.juv.bluestar.common.db.model.TicketBean bean = new com.juv.bluestar.common.db.model.TicketBean();
			bean = dbServiceImpl.getTicketDetails(ticketNumber);
			// Ticket Bean to Ticket
			if(bean != null){
				ticket.setTicketNumber(bean.getTicketNumber());
				ticket.setUpdatedOn(bean.getUpdatedOn());
				ticket.setProductId(bean.getProductId());
				ticket.setProductName(bean.getProductName());
				ticket.setStatus(bean.getStatus());
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return ticket;
	}
	
public ErrorMessage submitFeedback(SubmitFeedbackBean feedbackBean) throws Exception {
		
		ErrorMessage errorMessage = new ErrorMessage();
		
		if(feedbackBean != null){
			
			CustfeedbackDTO custfeedbackDTO = new CustfeedbackDTO();
			
			custfeedbackDTO.setMobileNo(feedbackBean.getMobileNumber());
			custfeedbackDTO.setPlatform(feedbackBean.getPlatform());
			custfeedbackDTO.setAuthKey(feedbackBean.getAuthKey());
			custfeedbackDTO.setTicketNo(feedbackBean.getTicketNumber());
			custfeedbackDTO.setRating(Integer.valueOf(feedbackBean.getRating()));
			custfeedbackDTO.setComments(feedbackBean.getComment());
			custfeedbackDTO.setCause(feedbackBean.getCause());
			
			try{
				
				
				/**
				 *		checking the ticket number exist or not 
				 */
				
				
				TicketAllDTO ticketAllDTO = new TicketAllDTO();
				ticketAllDTO.setTicketnumber(custfeedbackDTO.getTicketNo());
				List<TicketAllDTO> ticketDTOList = new TicketAllDBServiceImpl().isTicketNoExist(ticketAllDTO, null, false);
				
				if(ticketDTOList != null && ticketDTOList.size() > 0){
					
					
					/**
					 *		inserting feedback into database 
					 */
					
					
					long feedbackId = new CustfeedbackDBServiceImpl().insertSingleCustfeedback(custfeedbackDTO);
					
					if(feedbackId > 0){
						
						errorMessage.setErrorCode("1");
						errorMessage.setErrorMessage("feedback inserted successfully");
						errorMessage.setStatus("SUCCESS");
						
						return errorMessage;
					}else{
						
						errorMessage.setErrorCode("0");
						errorMessage.setErrorMessage("feedback not inserted successfully");
						errorMessage.setStatus("ERROR");
					}
				}else{
					
					errorMessage.setErrorCode("0");
					errorMessage.setErrorMessage("ticket no. does not exist");
					errorMessage.setStatus("ERROR");
				}
				
			}catch(Exception e){
				
				e.printStackTrace();
			}
		}
		return errorMessage;
	}


public List<StatusTrackingBean> getTicketHistory(StatusTrackingBean statTrackBean) throws Exception{
	
	List<StatusTrackingBean> statusTrackingBeanList = new ArrayList<StatusTrackingBean>();
	
	if(statTrackBean != null){
		
		List<Map<String, Object>> ticketHistoryList = new TicketAllDBServiceImpl().getTicketHistory(statTrackBean.getMobileNumber());
		
		if(ticketHistoryList != null && ticketHistoryList.size() > 0){
			
			for(Map<String, Object> ticketHistoryMap : ticketHistoryList){
				
				if(ticketHistoryMap != null && ticketHistoryMap.size() > 0 && !ticketHistoryMap.isEmpty()){
					
					StatusTrackingBean statusTrackingBean = new StatusTrackingBean();
					
					for(Map.Entry<String, Object> entry : ticketHistoryMap.entrySet()){
						
						if(entry.getKey() != null && entry.getValue() != null){
							
							if(entry.getKey().equalsIgnoreCase("TICKETNUMBER"))
								statusTrackingBean.setTicketNumber((String)entry.getValue());
							else if(entry.getKey().equalsIgnoreCase("PRODUCT_ID"))
								statusTrackingBean.setProductId((Integer)entry.getValue());
							else if(entry.getKey().equalsIgnoreCase("PRODUCTNAME"))
								statusTrackingBean.setProductName((String)entry.getValue());
							else if(entry.getKey().equalsIgnoreCase("STATUSDESCRIPTION"))
								statusTrackingBean.setProgressStatus((String)entry.getValue());
							else if(entry.getKey().equalsIgnoreCase("UPDATEDON"))
								statusTrackingBean.setLastUpdatedDate(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format((Timestamp)entry.getValue()));
						}
					}
					
					statusTrackingBean.setProductImage("http://203.76.134.156/EnhancedTheme/themes/html/Enhanced/css/images/bluestarAC.jpg");
					statusTrackingBeanList.add(statusTrackingBean);
				}
			}
			
			if(statusTrackingBeanList != null && statusTrackingBeanList.size() > 0){
				
				return statusTrackingBeanList;
			}
		}
	}
	return null;
}


public List<Notification> getNotificationsHistory(Notification notification) throws Exception {

	  List<Notification> notificationList = new ArrayList<Notification>();

	  if (notification != null) {

	   List<Map<String, Object>> ticketHistoryList = new TicketAllDBServiceImpl()
	     .getNotificationsHistory(notification.getMobileNumber());

	   if (ticketHistoryList != null && ticketHistoryList.size() > 0) {

	    for (Map<String, Object> ticketHistoryMap : ticketHistoryList) {

	     if (ticketHistoryMap != null && ticketHistoryMap.size() > 0 && !ticketHistoryMap.isEmpty()) {

	      notification = new Notification();

	      for (Map.Entry<String, Object> entry : ticketHistoryMap.entrySet()) {

	       if (entry.getKey() != null && entry.getValue() != null) {
	        if (entry.getKey().equalsIgnoreCase("PRODUCTID"))
	         notification.setProductId((Integer) entry.getValue());
	        else if (entry.getKey().equalsIgnoreCase("PRODUCTNAME"))
	         notification.setProductName((String) entry.getValue());
	       }
	      }
	     }

	     notificationList.add(notification);
	    }
	   }

	   if (notificationList != null && notificationList.size() > 0) {

	    System.out.println(notificationList.size());
	    return notificationList;
	   }

	  }

	  return null;
	 }



	/*public static void main(String[] args) throws Exception {*/
		
		
		
		
		
		
		
		
		/*CustomerService customerService = new CustomerService();
		String mobileNumber= "919711317798";
		List<Notification> list = customerService.getNotificationsHistory(mobileNumber);
		System.out.println("List :"+list);*/
		
		/*SubmitFeedbackBean submitFeedbackBean= new SubmitFeedbackBean();
		
		submitFeedbackBean.setMobileNumber("9999999999");
		submitFeedbackBean.setAuthKey("askhdkajs7868");
		submitFeedbackBean.setCause("ddddd");
		submitFeedbackBean.setComment("good");
		submitFeedbackBean.setPlatform("Android");
		submitFeedbackBean.setRating("3");
		submitFeedbackBean.setTicketNumber("B1104290002");
		
		new CustomerService().submitFeedback(submitFeedbackBean);*/
		/*CustomerService service = new CustomerService();
		com.juv.bluestar.common.db.model.TicketBean bean = new com.juv.bluestar.common.db.model.TicketBean();
		Ticket ticket  = new Ticket();
		try {
//			ticket = service.generateTicketNew("8800253402", 1001, "android");
			ticket = service.abc("B1608260002");
			System.out.println("Ticket : "+ticket.getTicketNumber()+
					"  Pro Id :"+ticket.getProductId()+
					 "  pro Name : "+ticket.getProductName()+
					"  sta : "+ticket.getStatus()+
					"  update On :"+ticket.getUpdatedOn());
		} catch (CustomerNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ProductNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		/*CustomerService customerService = new CustomerService();
		  try {
		   customerService.getStatusTracking("78383667970", "B1104290002");
		  } catch (Exception e) {
		   // TODO Auto-generated catch block
		   e.printStackTrace();
		  }

		  System.out.println("statusDto---");
		*/
	//}

	public boolean isalreadygenerated(String mobile, int productid)
			throws Exception {
		TicketAllDBServiceImpl ticketAllDBServiceImpl = null;
		TicketdetailsAllDTO ticketdetails = new TicketdetailsAllDTO();
		String query = "SELECT TICKET_ID FROM SERVEIT.TICKETDETAILS WHERE PRODUCT_ID="+productid+" AND UPDATEDBY='"+mobile+"' AND STATUS_ID NOT IN (1011,1012,1013,1014,1015)";
		List<Map<String, Object>> list = new TicketAllDBServiceImpl().executebyjdbcquery(query);
		if(list == null || list.size() < 0 )
			return false;
		else if(list.size() > 0)
			return true;
		
		
		return false;
	}
	
 public static void main(String[] args) {
	 UserBean userBean = new UserBean();
	 CustomerdetailsDTO customerdetails=new CustomerdetailsDTO();
	// userBean.setMobile("9778905678");
	 userBean.setAlternatemobilenumber("9089097655");
		//customerdetails.setPreferredtimingsfrom("17:07");
		//customerdetails.setPreferredtimingsto("14:10");
	 userBean.setSecurityQuestionAnswer("hello");
	 userBean.setSecurityQuestionId("What??");
	 userBean.setFirstName("ABCDE");
	 userBean.setLastName("EFGH");
	// userBean.setCustomername("ABCDCFFFF");
	 userBean.setEmail("gggg&gmail.com");
		CustomerdetailsDTO conditional = new CustomerdetailsDTO();
		conditional.setMobile("9778905678");
		
		
		CustomerService customerService = new CustomerService();
		try {
			customerService.registerUser(userBean, "9778905678");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	
}

public String findAuthKeyByAuthKey(String authKey,String mobileno) throws Exception {
	if(authKey != null && authKey.trim().length() > 0){

		
		/**
		 *		checking authKey exist or not
		 */
		
		
		List<Map<String, Object>> authKeyList = customerotpDBService.isAuthKeyExist(authKey,mobileno);

		if(authKeyList != null && authKeyList.size() > 0){

			for(Map<String, Object> authKeyMap : authKeyList){

				if(authKeyMap != null && authKeyMap.size() > 0){

					for(Map.Entry<String, Object> entry : authKeyMap.entrySet()){

						if(entry.getKey() != null && entry.getValue() != null){

							if(entry.getKey().trim().equalsIgnoreCase("AUTHKEY") && authKey.trim().equals((String)entry.getValue())){

								return (String)entry.getValue();
							}
						}
					}
				}
			}
		}
	}
	return null;
}

public String getauthkey(String mobileno) throws Exception {
	String authkey = null;
	CustomerotpDTO customerotpDTO = new CustomerotpDTO();
	customerotpDTO.setMobilenumber(Long.valueOf(mobileno));
	CustomerotpDBServiceImpl customerotpDBServiceImpl = new CustomerotpDBServiceImpl();
	List<CustomerotpDTO> list = customerotpDBServiceImpl.getCustomerotp(customerotpDTO, null, false);
	if(list.size() > 0){
		CustomerotpDTO custotp = list.get(0);
		authkey = custotp.getAuthkey();
	}
	return authkey;
}
	

}
