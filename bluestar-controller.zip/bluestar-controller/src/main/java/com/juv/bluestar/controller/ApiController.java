package com.juv.bluestar.controller;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.juv.bluestar.beans.ErrorMessage;
import com.juv.bluestar.beans.GenricRequestBean;
import com.juv.bluestar.beans.IbaseAddressBean;
import com.juv.bluestar.beans.Notification;
import com.juv.bluestar.beans.OTPMobileNoRequestBean;
import com.juv.bluestar.beans.ProductBean;
import com.juv.bluestar.beans.PushNotificationBean;
import com.juv.bluestar.beans.SecurityQuestionBean;
import com.juv.bluestar.beans.StatusTrackingBean;
import com.juv.bluestar.beans.SubmitFeedbackBean;
import com.juv.bluestar.beans.Ticket;
import com.juv.bluestar.beans.TicketRequestBean;
import com.juv.bluestar.beans.TicketLatestStatusBean;
import com.juv.bluestar.beans.UserBean;
import com.juv.bluestar.beans.UserRegistrationRequestBean;
import com.juv.bluestar.common.db.model.AddressmasterDTO;
import com.juv.bluestar.common.db.model.CustomerdetailsDTO;
import com.juv.bluestar.common.db.service.impl.AddressmasterDBServiceImpl;
import com.juv.bluestar.common.db.service.impl.CustfeedbackDBServiceImpl;
import com.juv.bluestar.common.db.service.impl.CustomerdetailsDBServiceImpl;
import com.juv.bluestar.common.exceptions.DBException;
import com.juv.bluestar.constants.BluestarConstants;
import com.juv.bluestar.exception.APIBusinessServiceException;
import com.juv.bluestar.helper.ApplicationLogger;
import com.juv.bluestar.helper.Utilities;
import com.juv.bluestar.service.ICustomerService;
import com.juv.bluestar.service.impl.CustomerServiceImpl;
import com.juv.bluestar.validation.APIValidation;
import com.juv.bluestar.validation.Nullvalidation;

@RestController
@ComponentScan(basePackages = { "com.juv.bluestar.*", "com.juv.*" })
/* @PropertySource("classpath:messages.properties") */
@RequestMapping(value = "/api/")
public class ApiController implements BluestarConstants {

	private ICustomerService customerService;
	private static Logger log =  LogManager.getLogger(ApiController.class);
	private static boolean isDebugEnabled = log.isDebugEnabled();
	private static boolean isInfoEnabled = log.isInfoEnabled();

	@Autowired
	public void setCustomerService(ICustomerService customerService) {
		this.customerService = customerService;
	}

	
	
	
	
	
	/**
	 * @author 				:
	 * @method 				:	genrateTicket
	 * @param 				: 	TicketRequestBean(mobileNumber,platform,authKey,productId,isForcefullyGenerated)
	 * @throws  			:	IOException 
	 * @throws 				:	APIBusinessServiceException 
	 * @RequestMapping 		: 	bean
	 * @RequestMethod 		: 	POST
	 * @exception 			: 	Exception
	 * @consumes 			: 	application/json
	 * @produced 			: 	application/json
	 */
	@RequestMapping(value = "ticket", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public ModelMap genrateTicket(@RequestBody TicketRequestBean bean) throws  IOException {
		
		if(log.isDebugEnabled()){
			log.debug("entering in genrateTicket() method ::: ");
			log.debug("bean ::: "+bean);
			log.info("mobileNumber ::: "+bean.getMobileNumber());
			log.info("authKey ::: "+bean.getAuthKey());
		}
		
		ModelMap modelMap = new ModelMap();
		String status = SUCCESS;
		String errorMessage = "";
		String message = "";
		if (bean == null) {
			status = ERROR;
		}else if ((errorMessage = APIValidation.validateAuthKey(bean.getAuthKey())) != null) {
			status = ERROR;
			message = "";
		} else {
			try {
				if ((errorMessage = APIValidation.validateMobileNumber(bean.getMobileNumber())) != null) {
					status = ERROR;
					message = "";
				}else {
					String authKey = null;
					authKey = this.customerService.findAuthKey(
							bean.getAuthKey(), bean.getMobileNumber());
					if (authKey == null) {

						errorMessage = APIValidation.apiValidationProperties.getProperty("authKey_invalid_error");
						status = ERROR;
						message = "";
					} 
					else {
						Ticket ticket = this.customerService.generateTicket(bean.getMobileNumber(), bean.getProductId(),
								bean.getPlatform(),
								bean.isIsForcefullyGenerated(),bean.getIbaseNumber());
						if (ticket != null) {
							if(ticket.getTicketNumber() == null){
								ticket.setTicketNumber("");
							}
							if(ticket.getProductName() == null){
								ticket.setProductName("");
							}
							if(ticket.getProductId() == 0 || ticket.getProductId() < 0){
								ticket.setProductId(0);
							}
							
							if(ticket.getStatus() == null){
								ticket.setStatus("");
							}
							if(ticket.getUpdatedOn() == null){
								ticket.setUpdatedOn("");
							}
							
							
							modelMap.addAttribute(AUTH_KEY, bean.getAuthKey());
							modelMap.addAttribute(TICKET_NUMBER,
									ticket.getTicketNumber());
							modelMap.addAttribute(PRODUCT_NAME,
									ticket.getProductName());
							modelMap.addAttribute(PROGRESS_STATUS,
									ticket.getStatus());
							modelMap.addAttribute(PRODUCTID,
									String.valueOf(ticket.getProductId()));
							modelMap.addAttribute(PROGRESS_STATUS,
									ticket.getStatus());
							modelMap.addAttribute(LASTUPDATEDDATE,
									ticket.getUpdatedOn());
							modelMap.addAttribute(IS_ALREADY_GENERATED, ticket.isAlreadyGenerated());
							message = APIValidation.apiValidationProperties.getProperty("registered_success");
						}
					}
				}
			} catch (APIBusinessServiceException e) {
				status = ERROR;
				log.error("Error at generate ticket cotroller :::"+e.getMessage());
				errorMessage = e.getMessage();
			}

		}
		
		if(isInfoEnabled)
			log.info("Exiting genrateTicket() method ::: ");
		if(errorMessage == null){
			errorMessage = "";
		}
		
		modelMap.addAttribute(STATUS, status);
		modelMap.addAttribute(MESSAGE, message);
		modelMap.addAttribute(ERROR_MESSAGE, errorMessage);
		return modelMap;
	}

	
	
	
	
	
	/**
	 * @author 				:
	 * @method 				: 	getProducts
	 * @param 				: 	bean, request
	 * @throws IOException 
	 * @RequestMapping 		: 	bean
	 * @RequestMethod 		: 	POST
	 * @exception 			: 	Exception
	 * @consumes 			: 	application/json
	 * @produced 			: 	application/json
	 */
	@RequestMapping(value = "product", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public ModelMap getProducts(@RequestBody GenricRequestBean bean,HttpServletRequest request) throws IOException {
		
		if(log.isDebugEnabled()){
			log.debug("entering in getProducts() method ::: ");
			log.debug("bean ::: "+bean);
			log.debug("request ::: "+request);
			log.info("mobileNumber ::: "+bean.getMobileNumber());
			log.info("authKey ::: "+bean.getAuthKey());
		}
		
		ModelMap modelMap = new ModelMap();
		String status = SUCCESS;
		String errorMessage = "";
		String message = "";
		String mobileNumber = String.valueOf(bean.getMobileNumber());
		if (bean != null) {
			if ((errorMessage = APIValidation.validateMobileNumber(bean.getMobileNumber())) != null) {
				status = ERROR;
				message = "";
			}else if ((errorMessage = APIValidation.validateAuthKey(bean.getAuthKey())) != null) {
				status = ERROR;
				message = "";
			}else {
				if (bean.getAuthKey() == null) {
					errorMessage = APIValidation.apiValidationProperties.getProperty("authKey_invalid_error");
					status = ERROR;
					message = "";
				}else{
					log.info("Auth key is not null");
					String authKey = null;
					try {
						authKey = this.customerService.findAuthKey(
								bean.getAuthKey(), bean.getMobileNumber());
						if ((errorMessage = APIValidation.validateInvalidAuthKey(authKey)) != null) {
							//errorMessage = "Authkey is not valid";
							status = ERROR;
							message = "";
						} else {
							List<ProductBean> list = this.customerService.getProducts();
							list=Nullvalidation.productNullValidate(list);
							if(list == null){
								list = new ArrayList<ProductBean>();
							}
							modelMap.addAttribute(PRODUCTS, list);
							modelMap.addAttribute(AUTH_KEY, authKey);
							message =  APIValidation.apiValidationProperties.getProperty("verified_success");

						}
					} catch (APIBusinessServiceException e) {
						// TODO Auto-generated catch block
						status = ERROR;
						errorMessage = e.getMessage();
						log.error("Error message :"+e);
					}
				}
			}
		} else {
			status = ERROR;
			errorMessage= APIValidation.apiValidationProperties.getProperty("bean_blank_error");
			message = "";
		}
		if(isInfoEnabled)
			log.info("getProducts(@RequestBody GenricRequestBean bean) method : End");
		if(message == null)
			message="";
		if(errorMessage == null)
			errorMessage = "";
		modelMap.addAttribute(STATUS, status);
		modelMap.addAttribute(MESSAGE, message);
		modelMap.addAttribute(ERROR_MESSAGE, errorMessage);
		return modelMap;
	}
	
	
	
	
	
	

	/**
	 * @author 				:
	 * @method 				: 	registerUser
	 * @param 				: 	bean
	 * @throws IOException 
	 * @RequestMapping 		: 	userregister
	 * @RequestMethod 		: 	POST
	 * @exception 			: 	Exception
	 * @consumes 			: 	application/json
	 * @produced 			: 	application/json
	 */
	@RequestMapping(value = "userregister", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public ModelMap registerUser(@RequestBody UserRegistrationRequestBean bean) throws IOException {
		if(log.isDebugEnabled()){
			log.debug("entering in registerUser() method ::: ");
			log.debug("bean ::: "+bean);
		}
		
		ModelMap modelMap = new ModelMap();
		String status = SUCCESS;
		String errorMessage = "";
		String message = "";
		String mobile = bean.getMobileNumber();
		UserBean beans = bean.getUser();
		if (bean == null) {
			status = ERROR;
			errorMessage= APIValidation.apiValidationProperties.getProperty("bean_blank_error");
		}else if ((errorMessage = APIValidation.validateMobileNumber(bean.getMobileNumber())) != null) {
			status = ERROR;
			message = "";
		}else if (bean.getUser() == null) {
			status = ERROR;
			errorMessage = APIValidation.apiValidationProperties.getProperty("userbean_blank_error");
		}else if ((errorMessage = APIValidation.validateAuthKey(bean.getAuthKey())) != null) {
			status = ERROR;
			message = "";
		} else {
			if (bean.getAuthKey() != null
					&& bean.getAuthKey().trim().length() > 0) {
				String authKey = null;
				try {
					authKey = this.customerService.findAuthKey(
							bean.getAuthKey(), bean.getMobileNumber());
					if ((errorMessage = APIValidation.validateInvalidAuthKey(authKey)) != null) {
						//errorMessage = "Authkey is not valid";
						status = ERROR;
						message = "";
					} else {
						UserBean user = bean.getUser();
						boolean b = this.customerService.registerUser(
								bean.getUser(), mobile);
						if (b) {
							status = SUCCESS;
							errorMessage = "";
							message = APIValidation.apiValidationProperties.getProperty("registered_success");
							modelMap.addAttribute(AUTH_KEY, bean.getAuthKey());
						}
					}

				}catch (APIBusinessServiceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					status = ERROR;
					errorMessage = e.getMessage();
					log.error("Error occured at business layer on userregistration Api:"+e);
				}
			}
		} 
		modelMap.addAttribute(STATUS, status);
		// modelMap.addAttribute(AUTH_KEY, bean.getAuthKey());
		modelMap.addAttribute(MESSAGE, message);
		if(errorMessage == null || errorMessage.equalsIgnoreCase(null)){
			modelMap.addAttribute(ERROR_MESSAGE, "");
		}
		
		modelMap.addAttribute(ERROR_MESSAGE, errorMessage);
		return modelMap;
	}

	
	
	
	
	
	/**
	 * @author 				:
	 * @method 				:	verifyQuestion
	 * @param 				: 	SecurityQuestionBean(mobileNumber,authKey,platform,securityId, securityAnswer)
	 * @throws 				:	IOException 
	 * @throws 				:	NumberFormatException 
	 * @RequestMapping 		: 	bean
	 * @RequestMethod 		: 	POST
	 * @exception 			: 	Exception
	 * @consumes 			: 	application/json
	 * @produced 			: 	application/json
	 */
	
	
	
	
	@RequestMapping(value = "verify/question", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public ModelMap verifyQuestion(@RequestBody SecurityQuestionBean bean) throws NumberFormatException, IOException {
		if(isInfoEnabled)
			log.info("verifyQuestion(@RequestBody SecurityQuestionBean bean) : Start");
		ModelMap modelMap = new ModelMap();
		String status = SUCCESS;
		String errorMessage = "";
		String message = "";
		String mobileNumber = String.valueOf(bean.getMobileNumber());
		try {
			if ((errorMessage = APIValidation.validateSecurityQuestationAnswer(bean.getSecurityId(),bean.getSecurityAnswer())) != null) {
				status = ERROR;
				message = "";
			}else if ((errorMessage = APIValidation.validateMobileNumber(bean.getMobileNumber())) != null) {
				status = ERROR;
				message = "";
			}else if ((errorMessage = APIValidation.validateAuthKey(bean.getAuthKey())) != null) {
				status = ERROR;
				message = "";
			}else {
				if (bean.getAuthKey() != null
						&& bean.getAuthKey().trim().length() > 0) {
					String authKey = null;
					authKey = this.customerService.findAuthKey(
							bean.getAuthKey(), bean.getMobileNumber());
					if ((errorMessage = APIValidation.validateInvalidAuthKey(authKey)) != null) {
						//errorMessage = "Authkey is not valid";
						status = ERROR;
						message = "";
					} else {

						boolean b = this.customerService
								.verifySecurityQuestion(
										bean.getMobileNumber(),
										bean.getSecurityId(),
										bean.getSecurityAnswer());
						if (b) {
							message = APIValidation.apiValidationProperties.getProperty("verified_success");
							modelMap.addAttribute(AUTH_KEY,
									bean.getAuthKey());
						} else {
							status = ERROR;
							message = " ";
							errorMessage = APIValidation.apiValidationProperties.getProperty("invalid_ans");
							modelMap.addAttribute(AUTH_KEY,
									bean.getAuthKey());
						}
					}
				}

			}
		} catch (APIBusinessServiceException e) {
			// TODO Auto-generated catch block
			status = ERROR;
			errorMessage = e.getMessage();
			log.error("Business Error :"+e);
		}
		if(isInfoEnabled)
			log.info("verifyQuestion(@RequestBody SecurityQuestionBean bean) : End");
		modelMap.addAttribute(STATUS, status);
		if(message == null)
			message = "";
		modelMap.addAttribute(MESSAGE, message);
		if(errorMessage == null)
			errorMessage = "";
		modelMap.addAttribute(ERROR_MESSAGE, errorMessage);
		return modelMap;
	}

	
	
	
	
	/**
	 * @author 			:
	 * @method 			: 	getOTP
	 * @param 			: 	OTPMobileNoRequestBean(mobileNumber,platform)
	 * @throws 			:	IOException 
	 * @RequestMapping 	: 	bean
	 * @RequestMethod 	: 	POST
	 * @exception 		: 	Exception
	 * @consumes 		: 	application/json
	 * @produced 		: 	application/json
	 */

	
	
	
	
	@RequestMapping(value = "requestotp", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public ModelMap getOTP(@RequestBody OTPMobileNoRequestBean bean) throws IOException {
		
		if(isInfoEnabled)
			log.info("getOTP(@RequestBody OTPMobileNoRequestBean bean) : Start");
		ModelMap modelMap = new ModelMap();
		String status = SUCCESS;
		String errorMessage = "";
		String message = "";
		String authkey1 = "";
		long mobi = bean.getMobileNumber();
		String mobile = String.valueOf(mobi);
		if (bean != null) {
			if ((errorMessage = APIValidation.validateMobileNumber(String.valueOf(bean.getMobileNumber()))) != null) {
				status = ERROR;
				message = "";
			}else if ((errorMessage = APIValidation.validatePlatform(String.valueOf(bean.getPlatform()))) != null) {
				status = ERROR;
				message = "";
			}else {
				try {
					Utilities utils;
					String authkey = new Utilities().getAuthKey();
					bean.setAuthKey(authkey);
					// bean.setPlatform(bean.get);
					bean.setOtpNumber(this.customerService.generateOTP());
					// ApplicationLogger.debug("GENERATED OTP: " +
					// otpVo.getOtp());

					boolean b = this.customerService.insertCustomerOTP(bean);
					if (b) {

						authkey1 = this.customerService.getAuthKey(String
								.valueOf(bean.getMobileNumber()));
					} else {

						authkey1 = " ";
					}
					log.debug(" INSERTPMSOTP() COMPLETE");
					this.customerService.sendSms(
							String.valueOf(bean.getMobileNumber()),
							"Dear Customer, your One Time Password (OTP) for Blue Star's Customer Care app is "
									+ bean.getOtpNumber() + "");
					message = APIValidation.apiValidationProperties.getProperty("otp_sent");
					status = SUCCESS;
				} catch (APIBusinessServiceException e) {
					message = APIValidation.apiValidationProperties.getProperty("server_error");
					status = ERROR;
					log.error("Server error "+e);
				}
			}
		} else {
			errorMessage = APIValidation.apiValidationProperties.getProperty("otp_bean_blank");
			status = ERROR;
			message = "";
		}
		if(isInfoEnabled)
			log.info("getOTP(@RequestBody OTPMobileNoRequestBean bean) : End");
		
		modelMap.addAttribute(STATUS, status);
		if(message == null)
			message = "";
		if(errorMessage == null)
			errorMessage = "";
		modelMap.addAttribute(MESSAGE, message);
		modelMap.addAttribute(ERROR_MESSAGE, errorMessage);
		// modelMap.addAttribute("apiname", "RequestOTP");
		modelMap.addAttribute(AUTH_KEY, authkey1);
		return modelMap;
	}

	
	
	
	
	
	/**
	 * @author :
	 * @method : verifyOTP
	 * @param : OTPMobileNoRequestBean(mobileNumber,otpNumber,platform,authKey)
	 * @RequestMapping : bean
	 * @RequestMethod : POST
	 * @exception : Exception
	 * @consumes : application/json
	 * @produced : application/json
	 */

	@RequestMapping(value = "verifyotp", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public ModelMap verifyOTP(@RequestBody OTPMobileNoRequestBean bean) throws Exception {
		
		if(isInfoEnabled){
			
			log.debug("Entering in verifyOTP() method ::: ");
			log.debug("bean ::: "+bean);
			log.info("mobileNumber ::: "+bean.getMobileNumber());
			log.info("authKey ::: "+bean.getAuthKey());
		}
		
		String message = "";
		String errorMessage = "";
		ModelMap modelMap = new ModelMap();
		String mobileNumber = String.valueOf(bean.getMobileNumber());
		String OTP = String.valueOf(bean.getOtpNumber());
		UserBean user1 = new UserBean();
		ApplicationLogger.debug("Request " + mobileNumber + ":" + OTP);
		String status = "error";
		AddressmasterDBServiceImpl addimpl = new AddressmasterDBServiceImpl();
		if ((errorMessage = APIValidation.validateMobileNumber(String.valueOf(bean.getMobileNumber()))) != null) {
			status = ERROR;
			message = "";
		}else if ((errorMessage = APIValidation.validateAuthKey(bean.getAuthKey())) != null) {
			status = ERROR;
			message = "";
		}else if (bean.getAuthKey() != null && bean.getAuthKey().trim().length() > 0) {

			String authKey = this.customerService.findAuthKey(bean.getAuthKey(), String.valueOf(bean.getMobileNumber()));

			if ((errorMessage = APIValidation.validateInvalidAuthKey(authKey)) != null) {
				//errorMessage = "Authkey is not valid";
				status = ERROR;
				message = "";
				modelMap.addAttribute(AUTH_KEY, bean.getAuthKey());
				modelMap.addAttribute(MESSAGE, message);
				modelMap.addAttribute(ERROR_MESSAGE, errorMessage);
				modelMap.addAttribute(STATUS, status);

				return modelMap;
			} else if (Integer.valueOf(bean.getOtpNumber()) == null
					|| bean.getOtpNumber() == 0) {
				status = ERROR;
				errorMessage = APIValidation.apiValidationProperties.getProperty("otp_provide_error");

			} else {
				boolean statusmsg = this.customerService
						.verifyOTPService(bean);
				if (statusmsg) {
					status = SUCCESS;
					errorMessage = "";
					message = APIValidation.apiValidationProperties.getProperty("otp_varify_success");

				} else {

					status = ERROR;
					errorMessage = APIValidation.apiValidationProperties.getProperty("invalid_otp");
				}
			}
		}
		if (status == SUCCESS) {
			log.info("If otp verified successfully");
			UserRegistrationRequestBean user = new UserRegistrationRequestBean();
			CustomerdetailsDTO customerdetailsDTO = new CustomerdetailsDTO();
			customerdetailsDTO.setMobile(String.valueOf(bean.getMobileNumber()));
			CustomerdetailsDBServiceImpl customerdetailsDBServiceimpl = new CustomerdetailsDBServiceImpl();
			CustomerdetailsDTO customerdetailsDTO2 = new CustomerdetailsDTO();
			
			try {
				List<CustomerdetailsDTO> userlist = customerdetailsDBServiceimpl.getCustomerdetails(customerdetailsDTO, null, false);
				log.debug("Customer list size ::"+userlist.size());
				if (userlist.size() < 0 || userlist.size() == 0) {
					/**
					 *		getting address from solar against mobile number 
					 */
					List<AddressmasterDTO> addresslist = null;
					try {
						addresslist = addimpl.getAddressFromSolarByMobileNo(mobileNumber);
					} catch (Exception e) {
						log.error("Error :: "+e.getMessage());
					}
					ArrayList<Object> addlist2 = null;
					if (addresslist != null && addresslist.size() > 0) {
						/*
						 * convert address list null value to blank.
						*/
						addresslist = Nullvalidation.addressNullValueToBlank(addresslist);
						int i = 0;
						addlist2 = new ArrayList<Object>();
						
						for (AddressmasterDTO addressmaster : addresslist) {
							
							Map<String, String> map3 = new HashMap<String, String>();
							map3.put("address", addressmaster.getAddress());
							map3.put("locality",addressmaster.getLocality());
							map3.put("pinCode", addressmaster.getPincode());
							map3.put("city", addressmaster.getCity());
							map3.put("state", addressmaster.getState());
							
							if(i == 0){
								map3.put("isPrimaryAddress", "true");
								i++;
							}else{
								map3.put("isPrimaryAddress", "false");
							}
								

							addlist2.add(map3);


							// addlist2.add(list2);
						}

					}
					if(addlist2 == null){
						addlist2 = new ArrayList<Object>();
						user1.setAddresses(addlist2);
					}else{
						user1.setAddresses(addlist2);	
					}
					// errorMessage ="user not found exception";
					log.info("User not found");
				} else {

					StatusTrackingBean statusTrackingBean = new StatusTrackingBean();
					statusTrackingBean.setMobileNumber(mobileNumber);
					List<StatusTrackingBean> statusTrackingBeanList = (List<StatusTrackingBean>) this.customerService
							.getTicketHistory(statusTrackingBean);

					List<Map<String, String>> tktHistoryList = new ArrayList<Map<String, String>>();

					if (statusTrackingBeanList != null
							&& statusTrackingBeanList.size() > 0) {
						log.debug("Tickethistory list size :"+statusTrackingBeanList.size());

						/*
						 * Convert any ticket null value to blank.
						*/
						statusTrackingBeanList = Nullvalidation.ticketNullValueToblank(statusTrackingBeanList);
						for (StatusTrackingBean statusTrackBean : statusTrackingBeanList) {

							Map<String, String> tktHistoryMap = new HashMap<String, String>();
							tktHistoryMap.put(TICKET_NUMBER,
									statusTrackBean.getTicketNumber());
							tktHistoryMap.put(PRODUCTID, String
									.valueOf(statusTrackBean.getProductId()));
							tktHistoryMap.put(PRODUCT_NAME,
									statusTrackBean.getProductName());
							tktHistoryMap.put(PROGRESS_STATUS,
									statusTrackBean.getProgressStatus());
							tktHistoryMap.put(PRODUCTIMAGE,
									statusTrackBean.getProductImage());
							tktHistoryMap.put(LASTUPDATEDDATE,
									statusTrackBean.getLastUpdatedDate());
							tktHistoryList.add(tktHistoryMap);

						}
						if(tktHistoryList == null){
							tktHistoryList = new ArrayList<Map<String, String>>();
							user1.setTickethistory(tktHistoryList);
						}else{
							user1.setTickethistory(tktHistoryList);	
						}
						

					}

					CustomerdetailsDTO customerdetailsDTO3 = new CustomerdetailsDTO();
					customerdetailsDTO3 = userlist.get(0);
					int customerid = (int) customerdetailsDTO3
							.getCustomerdetailsId();
					AddressmasterDTO addressmasterDTO = new AddressmasterDTO();
					addressmasterDTO.setCustomerid(customerid);
					ArrayList<Object> addlist2 = null;
					//List<AddressmasterDTO> addresslist = addimpl.getAddressmaster(addressmasterDTO, null, false);
					if((customerdetailsDTO3.getAddress1() == null || customerdetailsDTO3.getAddress1() == ""|| customerdetailsDTO3.getAddress1().equalsIgnoreCase("")) 
							&& (customerdetailsDTO3.getPinnumber() == null || customerdetailsDTO3.getPinnumber() == ""|| customerdetailsDTO3.getPinnumber().equalsIgnoreCase(""))){
						
					/**
					 *		getting address from solar against mobile number 
					 */
					
					List<AddressmasterDTO> addresslist = null;
					try {
						addresslist = addimpl.getAddressFromSolarByMobileNo(mobileNumber);
						
					} catch (Exception e) {
						
					}
					
					if (addresslist != null && addresslist.size() > 0) {
						/*
						 * convert address list null value to blank.
						*/
						addresslist = Nullvalidation.addressNullValueToBlank(addresslist);
						int i = 0;
						addlist2 = new ArrayList<Object>();
						
						for (AddressmasterDTO addressmaster : addresslist) {
							Map<String, String> map3 = new HashMap<String, String>();
							map3.put("address", addressmaster.getAddress());
							map3.put("locality",addressmaster.getLocality());
							map3.put("pinCode", addressmaster.getPincode());
							map3.put("city", addressmaster.getCity());
							map3.put("state", addressmaster.getState());
							
							if(i == 0){
								map3.put("isPrimaryAddress", "true");
								i++;
							}else{
								map3.put("isPrimaryAddress", "false");
							}
								

							addlist2.add(map3);


							// addlist2.add(list2);
						}
						

					}/*else{
						
						addlist2.add(APIValidation.apiValidationProperties.getProperty("user_address_not_found"));
					}*/
					}else{
						/*
						 * Address fetch from customer details table
						*/
						addlist2 = new ArrayList<Object>();
						
						Map<String, String> map3 = new HashMap<String, String>();
						map3.put("address", customerdetailsDTO3.getAddress1());
						map3.put("locality",customerdetailsDTO3.getLocality());
						map3.put("pinCode", customerdetailsDTO3.getPinnumber());
						map3.put("city", customerdetailsDTO3.getCity());
						map3.put("state", customerdetailsDTO3.getState());
						map3.put("isPrimaryAddress", "true");
						addlist2.add(map3);
						AddressmasterDTO addDto = new AddressmasterDTO();
						addDto.setCustomerid((int) customerdetailsDTO3.getCustomerdetailsId());
						AddressmasterDBServiceImpl addressImpl = new AddressmasterDBServiceImpl();
						List<AddressmasterDTO> addressLists = addressImpl.getAddressmaster(addDto, null, false);
						if(addressLists.size() > 0 && addressLists != null){
							for (AddressmasterDTO addressmasterDTO2 : addressLists) {
							 map3 = new HashMap<String, String>();
							 map3.put("address", addressmasterDTO2.getAddress());
							 map3.put("locality",addressmasterDTO2.getLocality());
							 map3.put("pinCode", addressmasterDTO2.getPincode());
							 map3.put("city", addressmasterDTO2.getCity());
							 map3.put("state", addressmasterDTO2.getState());
							 map3.put("isPrimaryAddress", "false");
							 addlist2.add(map3);
							}
						}
						
						
					}
					customerdetailsDTO2 = userlist.get(0);

					UserRegistrationRequestBean userBean = new UserRegistrationRequestBean();
					String names = customerdetailsDTO2.getCustomername();
					
					if (names == null || names == "") {
						user1.setFirstName(null);
						user1.setLastName(null);
					} else {
						String[] nameslist = {} ;
						if(names.contains(",")){
							nameslist = names.split(",");
						}else{
							nameslist = names.split(" ");
						}
						
						if(nameslist.length > 0){
							if (nameslist[0] == null || nameslist[0] == "") {
								user1.setFirstName(null);
							} else {
								user1.setFirstName(nameslist[0]);
							}
							if (nameslist[1] == null || nameslist[1] == "") {
								user1.setLastName(null);
							} else {
								user1.setLastName(nameslist[1]);
							}
						}
					}
					if(customerdetailsDTO2.getEmail() == null)
						user1.setEmail("");
					else
						user1.setEmail(customerdetailsDTO2.getEmail());
					if(customerdetailsDTO2.getSecurityquestion() == null)
						user1.setSecurityQuestionId("");
					else
						user1.setSecurityQuestionId(customerdetailsDTO2.getSecurityquestion());
					if(customerdetailsDTO2.getSecurityanswer() == null)
						user1.setSecurityQuestionAnswer("");
					else
						user1.setSecurityQuestionAnswer(customerdetailsDTO2.getSecurityanswer());
					
					user1.setPrefferedTimingFrom(customerdetailsDTO2.getPreferredtimingsfrom());
					user1.setPrefferedTimingTo(customerdetailsDTO2.getPreferredtimingsto());
					user1.setPin(customerdetailsDTO2.getPincode());
					user1.setAlternatemobilenumber(customerdetailsDTO2.getAlternatemobile());
					user1.setIbaseNumber(customerdetailsDTO2.getiBaseNumber());
					user1.setRegisteredProductsIds(customerdetailsDTO2.getProductTypeIds());						
					if(addlist2 == null){
						addlist2 = new ArrayList<Object>();
						user1.setAddresses(addlist2);
					}else{
						user1.setAddresses(addlist2);	
					}

				}
			} catch (APIBusinessServiceException e) {
				
				log.error("Business service exception at registration api ::"+e);
			}
			
			if(user1.getFirstName() == null){
				user1.setFirstName("");
			}
			if(user1.getLastName() == null){
				user1.setLastName("");
			}
			if(user1.getEmail() == null){
				user1.setEmail("");
			}
			if(user1.getSecurityQuestionId() == null){
				user1.setSecurityQuestionId("");
			}
			if(user1.getSecurityQuestionAnswer() == null){
				user1.setSecurityQuestionAnswer("");
			}
			if(user1.getPin() == null)
				user1.setPin("");
			if(user1.getAlternatemobilenumber() == null)
				user1.setAlternatemobilenumber("");
			if(user1.getIbaseNumber() == null)
				user1.setIbaseNumber("");
			if(user1.getRegisteredProductsIds() == null)
				user1.setRegisteredProductsIds("");
			if(user1.getAddresses() == null){
				ArrayList<Object> addlist2 = new ArrayList<Object>();
				user1.setAddresses(addlist2);
			}
			if(user1.getTickethistory() == null){
				List<Map<String, String>> list = new ArrayList<Map<String, String>>();
				user1.setTickethistory(list);
			}
			
			if (user1.getPrefferedTimingFrom() == null) {
				user1.setPrefferedTimingFrom("");
			}
			if (user1.getPrefferedTimingTo() == null) {
				user1.setPrefferedTimingTo("");
			}
			
			modelMap.addAttribute(USER, user1);
		}
		
		if(isInfoEnabled)
			log.info("verifyOTP metoh: End");
		
		modelMap.addAttribute(AUTH_KEY, bean.getAuthKey());
		modelMap.addAttribute(MESSAGE, message);
		modelMap.addAttribute(ERROR_MESSAGE, errorMessage);
		modelMap.addAttribute(STATUS, status);
		return modelMap;
	}

	/*
	 * This method will check your mobile number is numeric or not
	 */
	private static boolean isNumeric(String mobile) {
		boolean status = true;
		try {
			double d = Double.parseDouble(mobile);
		} catch (NumberFormatException ee) {
			status = false;
		}

		return status;
	}

	/**
	 * @author :
	 * @method : submitfeedback
	 * @param :
	 *        SubmitFeedbackBean(platform,authKey,ticketNumber,rating,comment,cause
	 *        )
	 * @RequestMapping : bean
	 * @RequestMethod : POST
	 * @exception : Exception
	 * @consumes : application/json
	 * @produced : application/json
	 */

	@RequestMapping(value = "submitfeedback", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public ModelMap submitfeedback(@RequestBody SubmitFeedbackBean feedback)
			throws Exception {
		if(isInfoEnabled)
			log.info("submitfeedback with SubmitFeedbackBean ["+feedback+"] : Start");
		ApplicationLogger.info("In Submit feedback");
		String status = SUCCESS;
		String message = "";
		String errorMessage = "";
		ModelMap modelMap = new ModelMap();
		String mobileNumber = String.valueOf(feedback.getMobileNumber());

		if ((errorMessage = APIValidation.validateMobileNumber(String.valueOf(feedback.getMobileNumber()))) != null) {
			status = ERROR;
			message = "";
		}else if ((errorMessage = APIValidation.validateAuthKey(feedback.getAuthKey())) != null) {
			status = ERROR;
			message = "";
		}else if ((errorMessage = APIValidation.validateTicketNumber(feedback.getTicketNumber())) != null) {
			status = ERROR;
			message = "";
		} else if ((errorMessage = APIValidation.validateRating(feedback.getRating())) != null) {
			status = ERROR;
			message = "";
		} else {
			if (feedback.getAuthKey() != null
					&& feedback.getAuthKey().trim().length() > 0) {

				String authKey = null;
				try {
					authKey = this.customerService.findAuthKey(
							feedback.getAuthKey(), feedback.getMobileNumber());

					if ((errorMessage = APIValidation.validateInvalidAuthKey(authKey)) != null) {
						status = ERROR;
						message = "";
					} else {
						ErrorMessage errMessage = this.customerService
								.submitFeedback(feedback);

						if (errMessage != null
								&& errMessage.getErrorCode().equals("1")) {

							status = SUCCESS;
							message = APIValidation.apiValidationProperties.getProperty("feedback_submitted");
							errorMessage = "";
						} else {
							status = ERROR;
							message = errMessage.getErrorMessage();
							errorMessage = "";
						}
					}
				} catch (APIBusinessServiceException e) {
					status = ERROR;
					log.error("Business service exception at submit feedback api ::"+e);

				}

			}

		}
		if(isInfoEnabled)
			log.info("submitfeedback method  : End");
		modelMap.addAttribute(STATUS, status);
		modelMap.addAttribute(MESSAGE, message);
		modelMap.addAttribute(ERROR_MESSAGE, errorMessage);
		return modelMap;
	}

	/**
	 * @author :
	 * @method : statustracking
	 * @param : StatusTrackingBean(mobileNumber,authKey,platform,ticketNumber)
	 * @throws IOException 
	 * @RequestMapping : statusTrackingBean
	 * @RequestMethod : POST
	 * @exception : Exception
	 * @consumes : application/json
	 * @produced : application/json
	 */
	@RequestMapping(value = "statustracking", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public ModelMap statustracking(
			@RequestBody StatusTrackingBean statusTrackingBean) throws IOException{
		if(isInfoEnabled)
			log.info("statustracking method with StatusTrackingBean ["+statusTrackingBean+"] : Start");
		ApplicationLogger.info("In Status tracking");
	
		String status = SUCCESS;
		String message = "";
		String errorMessage = "";
		String authkeyMessage = "";
		ModelMap modelMap = new ModelMap();
		String mobileNumber = String.valueOf(statusTrackingBean
				.getMobileNumber());
		String ticketNumber = statusTrackingBean.getTicketNumber();
		String authKey = statusTrackingBean.getAuthKey();
		String findAuthkey = null;

		if ((errorMessage = APIValidation.validateMobileNumber(String.valueOf(statusTrackingBean.getMobileNumber()))) != null) {
			status = ERROR;
			message = "";
		}else if ((errorMessage = APIValidation.validateAuthKey(statusTrackingBean.getAuthKey())) != null) {
			status = ERROR;
			message = "";
		}else if ((errorMessage = APIValidation.validateTicketNumber(statusTrackingBean.getTicketNumber())) != null) {
			status = ERROR;
			message = "";
		}else if (authKey != null) {
			try {
				findAuthkey = this.customerService.findAuthKey(authKey,
						mobileNumber);

				if ((errorMessage = APIValidation.validateInvalidAuthKey(findAuthkey)) != null) {
					status = ERROR;
					message = "";
				} else {

					authkeyMessage = findAuthkey;
					List<StatusTrackingBean> statusTrackinglist = null;
					statusTrackinglist = this.customerService
							.getStatusTracking(statusTrackingBean);
					if (statusTrackinglist == null
							|| statusTrackinglist.size() <= 0) {
						status = ERROR;
						message = "";
						errorMessage = APIValidation.apiValidationProperties.getProperty("ticketnumber_invalid");
					} else if (statusTrackinglist != null
							&& statusTrackinglist.size() > 0) {
						/*
						 * convert statusTracking bean any null value to blank
						*/
						statusTrackinglist = Nullvalidation.ticketNullValueToblank(statusTrackinglist);
						for (StatusTrackingBean statusTrackingBean1 : statusTrackinglist) {

							if ((errorMessage = APIValidation.validateInvalidTicketNumber(statusTrackingBean.getTicketNumber())) != null) {
								status = ERROR;
								message = "";
								//errorMessage = APIValidation.apiValidationProperties.getProperty("ticketnumber_invalid");
							} else {

								status = SUCCESS;
								modelMap.addAttribute(AUTH_KEY, authKey);
								modelMap.addAttribute(TICKET_NUMBER,
										statusTrackingBean1.getTicketNumber());
								modelMap.addAttribute(PRODUCTID,
										String.valueOf(statusTrackingBean1
												.getProductId()));
								modelMap.addAttribute(PRODUCT_NAME,
										statusTrackingBean1.getProductName());
								modelMap.addAttribute(LASTUPDATEDDATE,
										statusTrackingBean1.getLastUpdatedDate());
								modelMap.addAttribute(PROGRESS_STATUS,
										statusTrackingBean1.getProgressStatus());
								message = APIValidation.apiValidationProperties.getProperty("data_fetch_success");
								errorMessage = "";
							}
						}
					}
				}

			} catch (APIBusinessServiceException e) {
				status= ERROR;
				log.error("Business service exception in status tracking api"+e);
			}
		}
		if(isInfoEnabled)
			log.info("statustracking(@RequestBody StatusTrackingBean statusTrackingBean) : End");
		modelMap.addAttribute(STATUS, status);
		modelMap.addAttribute(MESSAGE, message);
		modelMap.addAttribute(ERROR_MESSAGE, errorMessage);
		return modelMap;
	}

	/**
	 * @author :
	 * @method : ticketHistory
	 * @param : statusTrackingBean
	 * @throws IOException 
	 * @RequestMapping : tickethistory
	 * @RequestMethod : POST
	 * @exception : Exception
	 * @consumes : application/json
	 * @produced : application/json
	 */

	@RequestMapping(value = "tickethistory", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public ModelMap ticketHistory(
			@RequestBody StatusTrackingBean statusTrackingBean) throws IOException {
		if(isInfoEnabled)
			log.info("ticketHistory method with StatusTrackingBean ["+statusTrackingBean+"]: Start");
		ApplicationLogger.info("In Ticket history");
		String status = SUCCESS;
		String message = "";
		String errorMessage = "";
		ModelMap modelMap = new ModelMap();

		String mobileNumber = String.valueOf(statusTrackingBean
				.getMobileNumber());
		if ((errorMessage = APIValidation.validateMobileNumber(mobileNumber)) != null) {
			status = ERROR;
			message = "";
		}else if ((errorMessage = APIValidation.validateAuthKey(statusTrackingBean.getAuthKey())) != null) {
			status = ERROR;
			message = "";
		} else if (statusTrackingBean.getAuthKey() != null
				&& statusTrackingBean.getAuthKey().trim().length() > 0) {

			String authKey;
			try {
				authKey = this.customerService.findAuthKey(
						statusTrackingBean.getAuthKey(), mobileNumber);


				if ((errorMessage = APIValidation.validateInvalidAuthKey(authKey)) != null) {
					status = ERROR;
					message = "";
				}else {
					List<StatusTrackingBean> statusTrackingBeanList = (List<StatusTrackingBean>) this.customerService
							.getTicketHistory(statusTrackingBean);
					List<Map<String, String>> tktHistoryList = new ArrayList<Map<String, String>>();
					if (statusTrackingBeanList == null) {
						status = SUCCESS;
						message = APIValidation.apiValidationProperties.getProperty("ticket_history_notfound_error");
						errorMessage = "";
					}else if (statusTrackingBeanList != null
							&& statusTrackingBeanList.size() > 0) {
						log.debug("Ticket list size :" + statusTrackingBeanList.size());
						status = SUCCESS;
						message = APIValidation.apiValidationProperties.getProperty("data_fetch_success");
						errorMessage = "";
						List<List<String>> ticketHistoryMasterList = new ArrayList<List<String>>();
						/*
						 * convert null value to blank.
						*/
						statusTrackingBeanList = Nullvalidation.ticketNullValueToblank(statusTrackingBeanList);
						
						for (StatusTrackingBean statusTrackBean : statusTrackingBeanList) {
							Map<String, String> map = new HashMap<String, String>();
							map.put(TICKET_NUMBER,
									statusTrackBean.getTicketNumber());
							map.put(PRODUCTID,
									String.valueOf(statusTrackBean.getProductId()));
							map.put(PRODUCT_NAME, statusTrackBean.getProductName());
							map.put(PROGRESS_STATUS,
									statusTrackBean.getProgressStatus());
							map.put(PRODUCTIMAGE, statusTrackBean.getProductImage());
							map.put(LASTUPDATEDDATE,
									statusTrackBean.getLastUpdatedDate());
							tktHistoryList.add(map);

						}

						modelMap.addAttribute("tickets", tktHistoryList);

					} else if (statusTrackingBeanList == null) {

						status = SUCCESS;
						message = "";
						errorMessage = APIValidation.apiValidationProperties.getProperty("ticket_history_notfound_error");
					}
				}

			} catch (APIBusinessServiceException e) {
				e.printStackTrace();
				log.error("Business service Exception at ticket history api:"+e);

			}
		}
		if(isInfoEnabled)
			log.info("ticketHistory : End");
		modelMap.addAttribute(STATUS, status);
		modelMap.addAttribute(MESSAGE, message);
		modelMap.addAttribute(ERROR_MESSAGE, errorMessage);

		return modelMap;
	}

	/**
	 * @author :
	 * @method : notificationHistory
	 * @param : notification
	 * @throws IOException 
	 * @RequestMapping : notificationhistory
	 * @RequestMethod : POST
	 * @exception : Exception
	 * @consumes : application/json
	 * @produced : application/json
	 */
	@RequestMapping(value = "notificationhistory", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public ModelMap notificationHistory(@RequestBody Notification notification) throws IOException {
		if(isInfoEnabled)
			log.info("notificationHistory method with Notification bean ["+notification+"] : Start");
		ApplicationLogger.info("In Notification history");
		String status = SUCCESS;
		String message = "";
		String errorMessage = "";
		ModelMap modelMap = new ModelMap();
		String mobileNumber = String.valueOf(notification.getMobileNumber());
		String authKey = notification.getAuthKey();
		if ((errorMessage = APIValidation.validateMobileNumber(mobileNumber)) != null) {
			status = ERROR;
			message = "";
		}else if ((errorMessage = APIValidation.validateAuthKey(notification.getAuthKey())) != null) {
			status = ERROR;
			message = "";
		} else if (authKey != null) {
			String findAuthkey;
			try {
				findAuthkey = this.customerService.findAuthKey(
						authKey, mobileNumber);

				if ((errorMessage = APIValidation.validateInvalidAuthKey(findAuthkey)) != null) {
					//errorMessage = " invalid Authkey.";
					status = ERROR;
					message = "";
					modelMap.addAttribute(STATUS, status);
					modelMap.addAttribute(MESSAGE, "No Notifications");
					modelMap.addAttribute(ERROR_MESSAGE, errorMessage);
				} else {
					List<Notification> notificationslist = null;
					notificationslist = this.customerService
							.getNotificationsHistory(notification);
					if (notificationslist != null && notificationslist.size() > 0) {
						/*
						 * Convert notification output null value to blank.
						*/
						notificationslist = Nullvalidation.notificationNullValueToBlank(notificationslist);
						Timestamp time = new Timestamp(new Date().getTime());
						status = SUCCESS;
						message = APIValidation.apiValidationProperties.getProperty("data_fetch_success");
						errorMessage = "";
						List<Object> list = new ArrayList<Object>();
						for (Notification notification2 : notificationslist) {

							HashMap<String, String> map = new HashMap<String, String>();
							map.put(MESSAGE, notification2.getNotificationMessage());
							map.put(PRODUCTID,
									String.valueOf(notification2.getProductId()));
							map.put(PRODUCT_NAME, notification2.getProductName());
							map.put(NOTIFICATIONTIME, String.valueOf(notification2.getNotificationTime()));
							list.add(map);
						}

						modelMap.addAttribute(NOTIFICATION, list);

						modelMap.addAttribute(STATUS, status);
						modelMap.addAttribute(MESSAGE, message);
						modelMap.addAttribute(ERROR_MESSAGE, errorMessage);
					}else{
						//modelMap.addAttribute(NOTIFICATION, list);
						status=SUCCESS;
						message=APIValidation.apiValidationProperties.getProperty("ticket_history_notfound_error");
						errorMessage="";
						modelMap.addAttribute(STATUS, status);
						modelMap.addAttribute(MESSAGE, message);
						modelMap.addAttribute(ERROR_MESSAGE, errorMessage);
					}
				}

			} catch (APIBusinessServiceException e) {
				e.printStackTrace();
				log.error("Business service exception at notifiaction history api"+e);
			}

		}
		if(isInfoEnabled)
			log.info("notificationHistory  : End");
		modelMap.addAttribute(STATUS, status);
		modelMap.addAttribute(MESSAGE, message);
		modelMap.addAttribute(ERROR_MESSAGE, errorMessage);

		return modelMap;
	}
	
	/**
	 * @author :
	 * @method : pushNotification
	 * @param : pushNotificationBean
	 * @throws IOException 
	 * @RequestMapping : push/notification
	 * @RequestMethod : POST
	 * @exception : Exception
	 * @consumes : application/json
	 * @produced : application/json
	 */
	@RequestMapping(value = "push/notification", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public ModelMap pushNotification(@RequestBody PushNotificationBean pushNotificationBean) throws IOException {
		ModelMap map = new ModelMap();
		if(isInfoEnabled)
			log.info("pushNotification method with PushNotificationBean bean ["+pushNotificationBean+"] : Start");
		ApplicationLogger.info("In push Notification ");
		String status = SUCCESS;
		String message = "";
		String errorMessage = "";
		String mobileNumber = String.valueOf(pushNotificationBean.getMobileNumber());
		
		if ((errorMessage = APIValidation.validateMobileNumber(mobileNumber)) != null) {
			status = ERROR;
			message = "";
		}else if ((errorMessage = APIValidation.validateDeviceToken(pushNotificationBean.getDeviceToken())) != null) {
			status = ERROR;
			message = "";
		}else if ((errorMessage = APIValidation.validatePlatform(pushNotificationBean.getPlatform())) != null) {
			status = ERROR;
			message = "";
		}else{
			try {
				String platform = pushNotificationBean.getPlatform().toUpperCase();
				pushNotificationBean.setPlatform(platform);
				boolean res = this.customerService.saveDeviceId(pushNotificationBean);
				if(res == true){
					status = SUCCESS;
					message =  APIValidation.apiValidationProperties.getProperty("device_token_success");
				}else{
					status = ERROR;
					errorMessage = APIValidation.apiValidationProperties.getProperty("device_token_error");
				}

			} catch (APIBusinessServiceException e) {
				log.error("Business service exception in status tracking api"+e);
				status = ERROR;
				errorMessage = e.getMessage();
			}

		}
		if(message == null)
			message = "";
		if(errorMessage == null)
			errorMessage = "";
		map.addAttribute(STATUS, status);
		map.addAttribute(MESSAGE, message);
		map.addAttribute(ERROR_MESSAGE, errorMessage);
		return map;
	}


	/**
	 * @author 				:
	 * @method 				: 	ticketStatus
	 * @param 				: 	ticketLatestStatusBean
	 * @throws ParseException 
	 * @purpose				:	to get the ticket latest status
	 * @RequestMapping 		: 	bean
	 * @RequestMethod 		: 	POST
	 * @throws 				:	IOException
	 * @exception 			: 	Exception
	 * @consumes 			: 	application/json
	 * @produced 			: 	application/json
	 */

	
	
	@RequestMapping(value = "ticketLatestStatus", method = RequestMethod.POST, consumes = "application/json")
	 @ResponseBody
	 public ModelMap getTicketLatestStatus(@RequestBody TicketLatestStatusBean ticketLatestStatusBean) throws IOException, ParseException {

	  if(isInfoEnabled){

	   log.info("entering in ticketStatus() method");
	   log.info("ticketStatusBean ::: "+ticketLatestStatusBean);
	   log.info("mobileNumber ::: "+ticketLatestStatusBean.getMobileNumber());
	   log.info("authKey ::: "+ticketLatestStatusBean.getAuthKey());
	   log.info("ticketNumber ::: "+ticketLatestStatusBean.getTicketNumber());
	  }

	  String status = SUCCESS;
	  String message = "";
	  String errorMessage = "";
	  ModelMap modelMap = null;

	  if(ticketLatestStatusBean != null){

	   modelMap = new ModelMap();


	   /**
	    *   validating Mobile Number, AuthKey and Ticket Number
	    */


	   if ((errorMessage = APIValidation.validateMobileNumber(ticketLatestStatusBean.getMobileNumber())) != null) {
	    status = ERROR;
	    message = "";
	   } else if ((errorMessage = APIValidation.validateAuthKey(ticketLatestStatusBean.getAuthKey())) != null) {
	    status = ERROR;
	    message = "";

	   }else{

	    try {

	     /**
	      *   getting AuthKey from authKey and mobile number
	      */
	     
	     String authKey = this.customerService.findAuthKey(ticketLatestStatusBean.getAuthKey(), ticketLatestStatusBean.getMobileNumber());

	     if (authKey == null) {

	      errorMessage = APIValidation.apiValidationProperties.getProperty("authKey_invalid_error");
	      status = ERROR;
	      message = "";

	     }else{

	      /**
	       *   calling getTicketLatestStatus method to get the latest ticket status
	       */

	      List<TicketLatestStatusBean> ticketLatestStatusList = this.customerService.getTicketLatestStatus(ticketLatestStatusBean);
	      if(ticketLatestStatusList != null && ticketLatestStatusList.size() > 0){
	    	  /*
	    	   * convert ticket latest status bean null value to blank.
	    	  */
	    	  ticketLatestStatusList = Nullvalidation.ticketLatestStatusNullToBlank(ticketLatestStatusList);
	       status = SUCCESS;
	       errorMessage = "";
	       message = APIValidation.apiValidationProperties.getProperty("data_fetch_success");
	       
	       List<Map<String, String>> ticketLatestStatusResponseList = new ArrayList<Map<String, String>>();

	       for(TicketLatestStatusBean ticketStatusBea : ticketLatestStatusList){

	        if(ticketStatusBea != null){
	         Map<String, String> ticketLatestStatusMap = new HashMap<String, String>();
	         
	         ticketLatestStatusMap.put(TICKET_NUMBER,ticketStatusBea.getTicketNumber());
	         ticketLatestStatusMap.put(PRODUCTID, ticketStatusBea.getProductId());
	         ticketLatestStatusMap.put(PRODUCT_NAME,ticketStatusBea.getProductName());
	         ticketLatestStatusMap.put(PRODUCTIMAGE, ticketStatusBea.getProductImage());
	         ticketLatestStatusMap.put(LASTUPDATEDDATE,String.valueOf(ticketStatusBea.getLastUpdatedDate()));
	         ticketLatestStatusMap.put(PROGRESS_STATUS,ticketStatusBea.getTicketStatus());
	         ticketLatestStatusMap.put(DEALER_NAME,ticketStatusBea.getDealerName());
	         ticketLatestStatusMap.put(DEALER_MOBILE,ticketStatusBea.getDealerPhoneNumber());
	         
	         ticketLatestStatusResponseList.add(ticketLatestStatusMap);
	        }
	       }
	       
	       modelMap.addAttribute(TICKET,ticketLatestStatusResponseList);
	      }else{
	    	  status = SUCCESS;
	    	  message = "No latest ticket history found";
	    	  errorMessage="";
	      }
	     }

	    } catch (APIBusinessServiceException e) {
	     status= ERROR;
	     errorMessage = e.getMessage();
	     log.error("Business service exception Message in ticket latest status api"+e.getMessage());
	     log.error("Business service exception in ticket latest status api"+e);
	     e.printStackTrace();
	    }
	   }
	  }else{
		  status=ERROR;
		  message="No latest ticket history found";
		  errorMessage="";
	  }

	  modelMap.addAttribute(STATUS, status);
	  modelMap.addAttribute(MESSAGE, message);
	  modelMap.addAttribute(ERROR_MESSAGE, errorMessage);
	  
	  if(isInfoEnabled){
	   log.info(STATUS+" ::: "+status);
	   log.info(MESSAGE+" ::: "+message);
	   log.info(ERROR_MESSAGE+" ::: "+errorMessage);
	   log.info("exiting ticketStatus() method");
	  }

	  return modelMap;
	 }
	
	
	@RequestMapping(value = "ibase/getaddresses", method = RequestMethod.POST, consumes = "application/json")
	  @ResponseBody
	  public ModelMap getIbaseAddresses(@RequestBody IbaseAddressBean ibaseAddressBean) throws IOException {
	   ModelMap map = new ModelMap();
	   if(isInfoEnabled)
	    log.info("getIbaseAddresses method with IbaseAddressBean ibaseAddressBean ["+ibaseAddressBean+"] : Start");
	   ApplicationLogger.info("In push Notification ");
	   String status = SUCCESS;
	   String message = "";
	   String errorMessage = "";
	   List<IbaseAddressBean> ibaseAddressBean2 = new ArrayList<IbaseAddressBean>();
	   if ((errorMessage = APIValidation.validateIbaseNumber(ibaseAddressBean.getIbaseNumber())) != null) {
	    status = ERROR;
	    message = "";
	   }else{
	    try {
	  ibaseAddressBean2 = this.customerService.getIbaseAddress(ibaseAddressBean.getIbaseNumber());
	     ArrayList<Object> addlist2 = new ArrayList<Object>();
	     log.debug("ibaseAddressBean2 ::"+ibaseAddressBean2 +"||   ibaseAddressBean2.size() ::"+ibaseAddressBean2.size());
	     if(ibaseAddressBean2 == null || ibaseAddressBean2.size() <= 0){
	      map.addAttribute("addresses", addlist2);
	      status=ERROR;
	      errorMessage=APIValidation.apiValidationProperties.getProperty("ibase_address_not_found");
	     }else if(ibaseAddressBean2 !=null){
	    	 ibaseAddressBean2 = Nullvalidation.ibaseAddressNullValueToBlank(ibaseAddressBean2);
	      for (IbaseAddressBean bean : ibaseAddressBean2){
	       Map<String, String> map3 = new HashMap<String, String>();
	          map3.put("address", bean.getAddress());
	          map3.put("city",bean.getCity());
	          map3.put("state",bean.getState());
	          map3.put("pincode", bean.getPincode());
	          map3.put("locality", "");
	          addlist2.add(map3);
	   }
	      map.addAttribute("addresses", addlist2);
	      status = SUCCESS;
	      message=APIValidation.apiValidationProperties.getProperty("ibase_address_fetched_successfully");
	     }
	    } catch (APIBusinessServiceException e) {
	     log.error("Business service exception in get IbaseAddress api"+e.getMessage());
	     status = ERROR;
	     errorMessage= e.getMessage();
	     e.printStackTrace();
	    }
	    
	   }
	   if(message == null)
		   message="";
	   if(errorMessage == null)
		   errorMessage = "";
	   map.addAttribute(STATUS, status);
	   map.addAttribute(MESSAGE, message);
	   map.addAttribute(ERROR_MESSAGE, errorMessage);
	   if(isInfoEnabled){
	   log.info(STATUS+" ::: "+status);
	   log.info(MESSAGE+" ::: "+message);
	   log.info(ERROR_MESSAGE+" ::: "+errorMessage);
	   log.info("exiting getIbaseAddresses() method");
	  }
	   return map;
	 }
	
}
