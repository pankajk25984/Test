package com.juv.bluestar.validation;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.juv.bluestar.beans.IbaseAddressBean;
import com.juv.bluestar.beans.Notification;
import com.juv.bluestar.beans.ProductBean;
import com.juv.bluestar.beans.StatusTrackingBean;
import com.juv.bluestar.beans.TicketLatestStatusBean;
import com.juv.bluestar.common.db.model.AddressmasterDTO;
import com.juv.bluestar.controller.ApiController;

public class Nullvalidation {
	private static Logger logger =  LogManager.getLogger(Nullvalidation.class);
	private static boolean isDebugEnabled = logger.isDebugEnabled();
	private static boolean isInfoEnabled = logger.isInfoEnabled();
	
	
	
	/**
	 * @author 			:	
	 * @method 			: 	productNullValidate
	 * @param 			: 	list
	 * @purpose			:	to conver null value to blank
	 * @return			:	return productBean list
	 * @exception 		: 	Exception
	 */
	public static List<ProductBean> productNullValidate(List<ProductBean> list){
		if(isInfoEnabled){
			logger.info("entering in productNullValidate() method ::: ");
			logger.info("List<ProductBean> list ::: "+list);
		}
		List<ProductBean> procudtlist = new ArrayList<ProductBean>();
		for (ProductBean productBean : list) {
			if(productBean.getProductId() == null){
				productBean.setProductId("");
			}
			if(productBean.getProductname() == null){
				productBean.setProductname("");
			}
			if(productBean.getProductDisplayName() == null){
				productBean.setProductDisplayName("");
			}
			if(productBean.getProductImage() == null)
				productBean.setProductImage("");
			procudtlist.add(productBean);
		}
		if(isInfoEnabled){
			logger.info("List ::: "+procudtlist);
			logger.info("exiting productNullValidate() method ::: ");
		}
	return procudtlist;
	}
	
	/**
	 * @author 			:	
	 * @method 			: 	ticketNullValueToblank
	 * @param 			: 	ticketsList
	 * @purpose			:	to conver null value to blank
	 * @return			:	return StatusTrackingBean list
	 * @exception 		: 	Exception
	 */
	public static List<StatusTrackingBean> ticketNullValueToblank(List<StatusTrackingBean> ticketsList){
		if(isInfoEnabled){
			logger.info("entering in ticketNullValueToblank() method ::: ");
			logger.info("List<StatusTrackingBean> ticketsList :"+ticketsList);
		}
		List<StatusTrackingBean> list = new ArrayList<StatusTrackingBean>();
		for (StatusTrackingBean statusTrackingBean : ticketsList) {
			if(0 == statusTrackingBean.getProductId())
				statusTrackingBean.setProductId(0);
			if(null == statusTrackingBean.getProductName())
				statusTrackingBean.setProductName("");
			if(null == statusTrackingBean.getProductImage())
				statusTrackingBean.setProductImage("");
			if(null == statusTrackingBean.getProgressStatus())
				statusTrackingBean.setProgressStatus("");
			if(null == statusTrackingBean.getTicketNumber())
				statusTrackingBean.setTicketNumber("");
			if(null == statusTrackingBean.getMobileNumber())
				statusTrackingBean.setMobileNumber("");
			if(null == statusTrackingBean.getLastUpdatedDate())
				statusTrackingBean.setLastUpdatedDate("");
			
			list.add(statusTrackingBean);
		}
		
		if(isInfoEnabled){
			logger.info("List ::: "+list);
			logger.info("exiting ticketNullValueToblank() method ::: ");
		}
		
		return list;
	}
	
	
	
	
	/**
	 * @author 			:	
	 * @method 			: 	addressNullValueToBlank
	 * @param 			: 	addressList
	 * @purpose			:	to convert null value to blank
	 * @return			:	return AddressmasterDTO list
	 * @exception 		: 	Exception
	 */
	public static List<AddressmasterDTO> addressNullValueToBlank(List<AddressmasterDTO> addressList){
		if(isInfoEnabled){
			logger.info("entering in addressNullValueToBlank() method ::: ");
			logger.info("List<AddressmasterDTO> addressList :"+addressList);
		}
		List<AddressmasterDTO> list = new ArrayList<AddressmasterDTO>();
		for (AddressmasterDTO addressmasterDTO : addressList) {
			if(null == addressmasterDTO.getAddress())
				addressmasterDTO.setAddress("");
			if(null == addressmasterDTO.getCity())
				addressmasterDTO.setCity("");
			if(null == addressmasterDTO.getState())
				addressmasterDTO.setState("");
			if(null == addressmasterDTO.getLocality())
				addressmasterDTO.setLocality("");
			if(null == addressmasterDTO.getPincode())
				addressmasterDTO.setPincode("");
			list.add(addressmasterDTO);
		}
		if(isInfoEnabled){
			logger.info("List ::: "+list);
			logger.info("exiting addressNullValueToBlank() method ::: ");
		}
		return list;
	}
	
	/**
	 * @author 			:	
	 * @method 			: 	notificationNullValueToBlank
	 * @param 			: 	notificationList
	 * @purpose			:	to convert null value to blank
	 * @return			:	return Notification list
	 * @exception 		: 	Exception
	 */
	public static List<Notification> notificationNullValueToBlank(List<Notification> notificationList){
		List<Notification> list = new ArrayList<Notification>();
		if(isInfoEnabled){
			logger.info("entering in notificationNullValueToBlank method ::: ");
			logger.info("List<Notification> notificationList :"+notificationList);
		}
		
		for (Notification notification : notificationList) {
			if(null == notification.getProductName())
				notification.setProductName("");
			if(notification.getProductId() == 0 || notification.getProductId() < 0)
				notification.setProductId(0);
			if(null == notification.getNotificationTime())
				notification.setNotificationTime("");
			if(null == notification.getNotificationMessage())
				notification.setNotificationMessage("");
			if(null == notification.getMobileNumber())
				notification.setMobileNumber("");
				
			list.add(notification);
		}
		if(isInfoEnabled){
			logger.info("List ::: "+list);
			logger.info("exiting notificationNullValueToBlank() method ::: ");
		}
		return list;
	}
	
	/**
	 * @author 			:	
	 * @method 			: 	ticketLatestStatusNullToBlank
	 * @param 			: 	ticketLatestStatus
	 * @purpose			:	to convert null value to blank
	 * @return			:	return TicketLatestStatusBean list
	 * @throws ParseException 
	 * @exception 		: 	Exception
	 */
	public static List<TicketLatestStatusBean> ticketLatestStatusNullToBlank(List<TicketLatestStatusBean> ticketLatestStatus) throws ParseException{
		List<TicketLatestStatusBean> list = new ArrayList<TicketLatestStatusBean>();
		if(isInfoEnabled){
			logger.info("entering in ticketLatestStatusNullToBlank method ::: ");
			logger.info("List<TicketLatestStatusBean> ticketLatestStatus :"+ticketLatestStatus);
		}
		
		for (TicketLatestStatusBean ticketLatestStatusBean : ticketLatestStatus) {
			if(null == ticketLatestStatusBean.getTicketStatus())
				ticketLatestStatusBean.setTicketStatus("");
			if(null == ticketLatestStatusBean.getTicketNumber())
				ticketLatestStatusBean.setTicketNumber("");
			if(null == ticketLatestStatusBean.getProductName())
				ticketLatestStatusBean.setProductName("");
			if(null == ticketLatestStatusBean.getProductImage())
				ticketLatestStatusBean.setProductImage("");
			if(null == ticketLatestStatusBean.getProductId())
				ticketLatestStatusBean.setProductId("");
			if(null == ticketLatestStatusBean.getMobileNumber())
				ticketLatestStatusBean.setMobileNumber("");
			if(null == ticketLatestStatusBean.getLastUpdatedDate())
				ticketLatestStatusBean.setLastUpdatedDate("");
			if(null == ticketLatestStatusBean.getDealerPhoneNumber())
				ticketLatestStatusBean.setDealerPhoneNumber("");
			if(null == ticketLatestStatusBean.getDealerName())
				ticketLatestStatusBean.setDealerName("");
			list.add(ticketLatestStatusBean);
		}
		if(isInfoEnabled){
			logger.info("List ::: "+list);
			logger.info("exiting ticketLatestStatusNullToBlank() method ::: ");
		}
		return list;
	}
	
	/**
	 * @author 			:	
	 * @method 			: 	addressNullValueToBlank
	 * @param 			: 	addressList
	 * @purpose			:	to convert null value to blank
	 * @return			:	return AddressmasterDTO list
	 * @exception 		: 	Exception
	 */
	public static List<IbaseAddressBean> ibaseAddressNullValueToBlank(List<IbaseAddressBean> addressList){
		if(isInfoEnabled){
			logger.info("entering in addressNullValueToBlank() method ::: ");
			logger.info("List<AddressmasterDTO> addressList :"+addressList);
		}
		List<IbaseAddressBean> list = new ArrayList<IbaseAddressBean>();
		for (IbaseAddressBean addressmasterDTO : addressList) {
			if(null == addressmasterDTO.getAddress())
				addressmasterDTO.setAddress("");
			if(null == addressmasterDTO.getCity())
				addressmasterDTO.setCity("");
			if(null == addressmasterDTO.getState())
				addressmasterDTO.setState("");
			if(null == addressmasterDTO.getPincode())
				addressmasterDTO.setPincode("");
			list.add(addressmasterDTO);
		}
		if(isInfoEnabled){
			logger.info("List ::: "+list);
			logger.info("exiting addressNullValueToBlank() method ::: ");
		}
		return list;
	}
	
	
}
