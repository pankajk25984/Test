package com.juv.bluestar.validation;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.juv.bluestar.controller.ApiController;

public class APIValidation {

	public static Properties apiValidationProperties;
	private static Logger logger =  LogManager.getLogger(ApiController.class);
	private static boolean isDebugEnabled = logger.isDebugEnabled();
	private static boolean isInfoEnabled = logger.isInfoEnabled();


	static{
		apiValidationProperties = new Properties();
		try {
			apiValidationProperties.load(APIValidation.class.getClassLoader().getResourceAsStream("/ApiValidation.properties"));
		} catch (FileNotFoundException e) {
			logger.error("Unable to initialize BusinessService.properties bundle at path '/'", e);
		} catch (IOException e) {
			logger.error("Unable to initialize BusinessService.properties bundle at path '/'", e);
		}
	}





	/**
	 * @author 			:	
	 * @method 			: 	validateMobileNumber
	 * @param 			: 	mobileNumber
	 * @purpose			:	to validate mobile number
	 * @return			:	errorMessage
	 * @exception 		: 	Exception
	 */




	public static String validateMobileNumber(String mobileNumber) throws IOException {
		
		if(isInfoEnabled){
			logger.info("entering in validateMobileNumber() method ::: ");
			logger.info("mobileNumber ::: "+mobileNumber);
		}

		String errorMessage = null;
		int mobileNoLength = Integer.parseInt(apiValidationProperties.getProperty("mobile_no_length"));

		if(mobileNumber != null && mobileNumber.length() > 0){

			if(!isNumeric(mobileNumber))
				errorMessage = apiValidationProperties.getProperty("mobile_invalid_error");
			else if(mobileNumber.length() < mobileNoLength || mobileNumber.length() > mobileNoLength)
				errorMessage = apiValidationProperties.getProperty("mobile_length_error");
		}else{

			if(mobileNumber == null)
				errorMessage = apiValidationProperties.getProperty("mobile_null_error");
			else if(mobileNumber == "")
				errorMessage = apiValidationProperties.getProperty("mobile_blank_error");
		}

		if(isInfoEnabled){
			logger.info("errorMessage ::: "+errorMessage);
			logger.info("exiting validateMobileNumber() method ::: ");
		}
		
		return errorMessage;
	}





	/**
	 * @author 			:	
	 * @method 			: 	validateAuthKey
	 * @param 			: 	authKey
	 * @purpose			:	to validate authKey
	 * @return			:	errorMessage
	 * @exception 		: 	Exception
	 */




	public static String validateAuthKey(String authKey) throws IOException{

		if(isInfoEnabled){
			
			logger.info("entering in validateAuthKey() method ::: ");
			logger.info("authKey ::: "+authKey);
		}

		String errorMessage = null;
		
		if(authKey == null)
			errorMessage = apiValidationProperties.getProperty("authKey_null_error");
		else if(authKey.length() <= 0 || authKey == "")
			errorMessage = apiValidationProperties.getProperty("authKey_blank_error");

		if(isInfoEnabled){
			logger.info("errorMessage ::: "+errorMessage);
			logger.info("exiting validateAuthKey() method ::: ");
		}
		
		return errorMessage;
	}
	
	
	
	
	
	/**
	 * @author 			:	
	 * @method 			: 	validateTicketNumber
	 * @param 			: 	ticketNumber
	 * @purpose			:	to validate ticket number
	 * @return			:	errorMessage
	 * @exception 		: 	Exception
	 */




	public static String validateTicketNumber(String ticketNumber) throws IOException{

		if(isInfoEnabled){
			
			logger.info("entering in validateTicketNumber() method ::: ");
			logger.info("ticketNumber ::: "+ticketNumber);
		}

		String errorMessage = null;
		
		if(ticketNumber == null)
			errorMessage = apiValidationProperties.getProperty("ticket_null_error");
		else if(ticketNumber.length() <= 0 || ticketNumber == "")
			errorMessage = apiValidationProperties.getProperty("ticket_blank_error");

		if(isInfoEnabled){
			logger.info("errorMessage ::: "+errorMessage);
			logger.info("exiting validateTicketNumber() method ::: ");
		}
		
		return errorMessage;
	}
	
	
	
	
	
	/**
	 * @author 			:	
	 * @method 			: 	validatePlatform
	 * @param 			: 	platform
	 * @purpose			:	to validate device platform
	 * @return			:	errorMessage
	 * @exception 		: 	Exception
	 */




	public static String validatePlatform(String platform) throws IOException{

		if(isInfoEnabled){
			
			logger.info("entering in validatePlatform() method ::: ");
			logger.info("platform ::: "+platform);
		}

		String errorMessage = null;
		
		if(platform == null)
			errorMessage = apiValidationProperties.getProperty("platform_null_error");
		else if(platform.length() <= 0 || platform == "")
			errorMessage = apiValidationProperties.getProperty("platform_blank_error");

		if(isInfoEnabled){
			logger.info("errorMessage ::: "+errorMessage);
			logger.info("exiting validateTicketNumber() method ::: ");
		}
		
		return errorMessage;
	}

	
	
	
	
	/**
	 * @author 			:	
	 * @method 			: 	validateSecurityId
	 * @param 			: 	securityId
	 * @purpose			:	to validate securityId
	 * @return			:	errorMessage
	 * @exception 		: 	Exception
	 */




	public static String validateSecurityId(String securityId) throws IOException{

		if(isInfoEnabled){
			
			logger.info("entering in validateSecurityId() method ::: ");
			logger.info("securityId ::: "+securityId);
		}

		String errorMessage = null;
		
		if(securityId == null)
			errorMessage = apiValidationProperties.getProperty("securityId_null_error");
		else if(securityId.length() <= 0 || securityId == "")
			errorMessage = apiValidationProperties.getProperty("securityId_blank_error");

		if(isInfoEnabled){
			logger.info("errorMessage ::: "+errorMessage);
			logger.info("exiting validateSecurityId() method ::: ");
		}
		
		return errorMessage;
	}
	
	
	
	
	
	/**
	 * @author 			:	
	 * @method 			: 	validateSecurityAnswer
	 * @param 			: 	securityAnswer
	 * @purpose			:	to validate security answer
	 * @return			:	errorMessage
	 * @exception 		: 	Exception
	 */




	public static String validateSecurityAnswer(String securityAnswer) throws IOException{

		if(isInfoEnabled){
			
			logger.info("entering in validateSecurityAnswer() method ::: ");
			logger.info("securityAnswer ::: "+securityAnswer);
		}

		String errorMessage = null;
		
		if(securityAnswer == null)
			errorMessage = apiValidationProperties.getProperty("securityAnswer_null_error");
		else if(securityAnswer.length() <= 0 || securityAnswer == "")
			errorMessage = apiValidationProperties.getProperty("securityAnswer_blank_error");

		if(isInfoEnabled){
			logger.info("errorMessage ::: "+errorMessage);
			logger.info("exiting validateSecurityAnswer() method ::: ");
		}
		
		return errorMessage;
	}
	
	
	
	
	
	/**
	 * @author 			:	
	 * @method 			: 	validateOtpNumber
	 * @param 			: 	otpNumber
	 * @purpose			:	to validate OTP number
	 * @return			:	errorMessage
	 * @exception 		: 	Exception
	 */




	public static String validateOtpNumber(String otpNumber) throws IOException{

		if(isInfoEnabled){
			
			logger.info("entering in validateOtpNumber() method ::: ");
			logger.info("otpNumber ::: "+otpNumber);
		}

		String errorMessage = null;
		
		if(otpNumber == null)
			errorMessage = apiValidationProperties.getProperty("otp_null_error");
		else if(otpNumber.length() <= 0 || otpNumber == "")
			errorMessage = apiValidationProperties.getProperty("otp_blank_error");

		if(isInfoEnabled){
			logger.info("errorMessage ::: "+errorMessage);
			logger.info("exiting validateOtpNumber() method ::: ");
		}
		
		return errorMessage;
	}

	
	
	
	
	/**
	 * @author 			:	
	 * @method 			: 	validateIbaseNumber
	 * @param 			: 	ibaseNumber
	 * @purpose			:	to validate iBase Number
	 * @return			:	errorMessage
	 * @exception 		: 	Exception
	 */
	
	
	
	
	public static String validateIbaseNumber(String ibaseNumber) throws IOException{

		  if(isInfoEnabled){
		   
		   logger.info("entering in validateIbaseNumber() method");
		   logger.info("platform ::: "+ibaseNumber);
		  }

		  String errorMessage = null;
		  
		  if(ibaseNumber == null)
		   errorMessage = apiValidationProperties.getProperty("");
		  else if(ibaseNumber.length() <= 0 || ibaseNumber == "ibase_null_error")
		   errorMessage = apiValidationProperties.getProperty("ibase_blank_error");

		  if(isInfoEnabled){
		   logger.info("errorMessage ::: "+errorMessage);
		   logger.info("exiting validateIbaseNumber() method");
		  }
		  
		  return errorMessage;
		 }
	

	/**
	 * @author 			:	
	 * @method 			: 	validateSecurityQuestationAnswer
	 * @param 			: 	securityId,securityAnswer
	 * @purpose			:	to check security question and answer is blank and null or not 
	 * @return			:	status
	 * @exception 		: 	Exception
	 */
	public static String validateSecurityQuestationAnswer(String securityId,String securityAnswer) throws IOException{

		if(isInfoEnabled){
			
			logger.info("entering in validateSecurityQuestationAnswer() method ::: ");
			logger.info("securityId ::: "+securityId);
			logger.info("securityAnswer ::: "+securityAnswer);
		}

		String errorMessage = null;
		
		if(securityId == null)
			errorMessage = apiValidationProperties.getProperty("securityid_null_error");
		else if(securityId.length() <= 0 || securityId == "")
			errorMessage = apiValidationProperties.getProperty("securityid_null_error");
		else if (securityAnswer == null) 	
			errorMessage = apiValidationProperties.getProperty("security_answer_error");
		else if(securityAnswer.length() <= 0 || securityAnswer == "")
			errorMessage = apiValidationProperties.getProperty("security_answer_error");
		if(isInfoEnabled){
			logger.info("errorMessage ::: "+errorMessage);
			logger.info("exiting validateSecurityQuestationAnswer() method ::: ");
		}
		
		return errorMessage;
	}

	/**
	 * @author 			:	
	 * @method 			: 	validateRating
	 * @param 			: 	rating
	 * @purpose			:	to check feedback rating
	 * @return			:	status
	 * @exception 		: 	Exception
	 */
	public static String validateRating(String rating) throws IOException{

		if(isInfoEnabled){
			
			logger.info("entering in validateRating() method ::: ");
			logger.info("Rating ::: "+rating);
		}

		String errorMessage = null;
		
		if(rating == null)
			errorMessage = apiValidationProperties.getProperty("feedback_rating_null_error");
		else if(rating.length() <= 0 || rating == "")
			errorMessage = apiValidationProperties.getProperty("feedback_rating_blank_error");
		if(isInfoEnabled){
			logger.info("errorMessage ::: "+errorMessage);
			logger.info("exiting validateRating() method ::: ");
		}
		
		return errorMessage;
	}

	
	
	/**
	 * @author 			:	
	 * @method 			: 	validateInvalidAuthKey
	 * @param 			: 	authKey
	 * @purpose			:	to check Invalid authkey
	 * @return			:	status
	 * @exception 		: 	Exception
	 */
	public static String validateInvalidAuthKey(String authKey) throws IOException{

		if(isInfoEnabled){
			
			logger.info("entering in validateInvalidAuthKey() method ::: ");
			logger.info("authKey ::: "+authKey);
		}

		String errorMessage = null;
		
		if(authKey == null)
			errorMessage = apiValidationProperties.getProperty("authKey_invalid_error");
		else if(authKey.length() <= 0 || authKey == "")
			errorMessage = apiValidationProperties.getProperty("authKey_invalid_error");
		if(isInfoEnabled){
			logger.info("errorMessage ::: "+errorMessage);
			logger.info("exiting validateInvalidAuthKey() method ::: ");
		}
		
		return errorMessage;
	}
	
	/**
	 * @author 			:	
	 * @method 			: 	validateInvalidTicketNumber
	 * @param 			: 	ticketNumber
	 * @purpose			:	to check Invalid ticketNumber
	 * @return			:	status
	 * @exception 		: 	Exception
	 */
	public static String validateInvalidTicketNumber(String ticketNumber) throws IOException{

		if(isInfoEnabled){
			
			logger.info("entering in validateInvalidTicketNumber() method ::: ");
			logger.info("ticketNumber ::: "+ticketNumber);
		}

		String errorMessage = null;
		
		if(ticketNumber == null)
			errorMessage = apiValidationProperties.getProperty("ticketnumber_invalid");
		else if(ticketNumber.length() <= 0 || ticketNumber == "")
			errorMessage = apiValidationProperties.getProperty("ticketnumber_invalid");
		if(isInfoEnabled){
			logger.info("errorMessage ::: "+errorMessage);
			logger.info("exiting validateInvalidTicketNumber() method ::: ");
		}
		
		return errorMessage;
	}
	
	
	
	
	/**
	 * @author 			:	
	 * @method 			: 	validateDeviceToken
	 * @param 			: 	deviceToken
	 * @purpose			:	Validate device token
	 * @return			:	status
	 * @exception 		: 	Exception
	 */
	public static String validateDeviceToken(String deviceToken) throws IOException{

		if(isInfoEnabled){
			
			logger.info("entering in validateDeviceToken() method ::: ");
			logger.info("deviceToken ::: "+deviceToken);
		}

		String errorMessage = null;
		if(deviceToken == null)
			errorMessage = apiValidationProperties.getProperty("device_token_null_error");
		else if(deviceToken.length() <= 0 || deviceToken == "")
			errorMessage = apiValidationProperties.getProperty("device_token_blank_error");
		if(isInfoEnabled){
			logger.info("errorMessage ::: "+errorMessage);
			logger.info("exiting validateDeviceToken() method ::: ");
		}
		
		return errorMessage;
	}

	/**
	 * @author 			:	
	 * @method 			: 	isNumeric
	 * @param 			: 	mobile
	 * @purpose			:	to check mobile number is numeric or not
	 * @return			:	status
	 * @exception 		: 	Exception
	 */
	
	
	
	
	private static boolean isNumeric(String mobileNumber) throws NumberFormatException {
		
		if(isInfoEnabled){
			logger.info("entering in isNumeric() method ::: ");
			logger.info("mobileNumber ::: "+mobileNumber);
		}
		
		boolean status = true;
		try {
			double d = Double.parseDouble(mobileNumber);
		} catch (NumberFormatException ee) {
			status = false;
		}
		
		if(isInfoEnabled){
			logger.info("status ::: "+status);
			logger.info("exiting isNumeric() method ::: ");
		}

		return status;
	}
}
